import React from 'react';
import {auth, createUserProfileDocument} from './src/firebase.js';
import { MyInput } from './input';
import { MyButton } from './button';
import './sign-up.scss';

class SignUp extends React.Component {
    constructor() {
        super();

        this.state = {
            userName: '',
            email: '',
            password1: '',
            password2: ''
        };
    }

    handleSubmit = async event =>  {
        event.preventDefault();

        if (this.state.password1 != this.state.password2){
            alert("passwords do not match!");
            return;
        }

        try {
            const {user} = await auth.createUserWithEmailAndPassword(this.state.email,this.state.password1);
            await createUserProfileDocument(user,this.state.userName);
            this.setState({userName: '',email: '',password1:'',password2:''});
        }
        catch (error) {
            alert(error);
        }
    }

    handleChange = event => {
        const {value,name} = event.target;
        this.setState({ [name]: value });
    }


    render() {
        return(
            <div>
                <h2>sign up with email and password</h2>
                <form onSubmit = {this.handleSubmit}>
                    <MyInput onChange = {this.handleChange} type="text" name='user name' value={this.state.userName} required lbl = 'userName' />
                    <MyInput onChange = {this.handleChange} type="email" name='email' value={this.state.email} required lbl = 'email' />
                    <MyInput onChange = {this.handleChange} type="password" name='password' value={this.state.password} required lbl = 'password' />
                    <MyInput onChange = {this.handleChange} type="password" name='comfirm password' value={this.state.password} required lbl = 'password' />
                    <MyButton type="submit" lbl='sign up'/>
                </form>

            </div>
        ); 
    }
}

export default SignUp;