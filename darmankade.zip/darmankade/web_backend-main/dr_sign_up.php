<?php include('dr_server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dr_sign_up</title>
</head>
<body>
    
    <form action="dr_sign_up.php" method="POST">
    <?php include('errors.php'); ?>
        <div>
            <label for="username">username :</label>
            <input type="text" name="username" required value="<?php echo $username; ?>">
        </div>
        
        <div>
            <label for="phone">phone :</label>
            <input type="text" name="phone" required value="<?php echo $phone; ?>">
        </div>

        <div>
            <label for="password">password :</label>
            <input type="password" name="password_1" required>
        </div>
        <div>
            <label for="password">confirm password :</label>
            <input type="password" name="password_2" required>
        </div>

        <div>
            <label for="name">name :</label>
            <input type="text" name="name" required>
        </div>

        <div>
            <label for="number">number :</label>
            <input type="text" name="number" required>
        </div>

        <div>
            <label for="experience_years">experience_years :</label>
            <input type="number" name="experience_years" required>
        </div>

        <div>
            <label for="address">address :</label>
            <input type="text" name="address" required>
        </div>
        <fieldset>
    <legend> :تخصص را انتخاب کنید </legend>
    <div>
    <label for="contactChoice1">قلب</label>
      <input type="radio"
       name="spec" value="1">
      
       <label for="contactChoice2">مغز</label>
      <input type="radio" 
       name="spec" value="2">
      
       <label for="contactChoice3">رادیولوژی</label>
      <input type="radio" 
       name="spec" value="3">
      
    </div>
        </fieldset>
    <fieldset>
    <legend> :نوع ویزیت را انتخاب کنید </legend>
    <div>
        <label for="online_pay">ندارد</label>
      <input type="radio" 
       name="online_pay" value="y">
      
       <label for="online_pay">دارد</label>
      <input type="radio" 
       name="online_pay" value="n">
      
    </div>
    </fieldset>

    <fieldset>
    <legend> :روز های فعال در هفته را انتخاب کن </legend>
    <div>
      <input type="checkbox" 
       name="days[]" value="0" checked>
      <label for="contactChoice1">شنبه</label>

      <input type="checkbox" 
       name="days[]" value="1" checked>
      <label for="contactChoice1"> یک شنبه</label>

      <input type="checkbox" 
       name="days[]" value="2" checked>
      <label for="contactChoice1">دو شنبه</label>

      <input type="checkbox" 
       name="days[]" value="3" checked>
      <label for="contactChoice1">سه شنبه</label>

      <input type="checkbox" 
       name="days[]" value="4" checked>
      <label for="contactChoice1">چهار شنبه</label>

      <input type="checkbox" 
       name="days[]" value="5" checked>
      <label for="contactChoice1">پنج شنبه</label>

      <input type="checkbox" 
       name="days[]" value="6" checked>
      <label for="contactChoice1">جمعه</label>
    </div>
    </fieldset>
    
        <button type="submit" name="dr_sign_up">submit</button>

    </form>
    
</body>
</html>