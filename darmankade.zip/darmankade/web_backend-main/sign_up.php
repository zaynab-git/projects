<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sign_up</title>
</head>
<body>
    
    <form action="sign_up.php" method="POST">
    <?php include('errors.php'); ?>
        <div>
            <label for="username">username :</label>
            <input type="text" name="username" required value="<?php echo $username; ?>">
        </div>
        
        <div>
            <label for="phone">phone :</label>
            <input type="text" name="phone" required value="<?php echo $phone; ?>">
        </div>

        <div>
            <label for="password">password :</label>
            <input type="password" name="password_1" required>
        </div>
        <div>
            <label for="password">confirm password :</label>
            <input type="password" name="password_2" required>
        </div>

        <button type="submit" name="sign_up">submit</button>

    </form>
    
</body>
</html>