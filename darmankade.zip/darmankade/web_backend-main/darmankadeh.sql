-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2021 at 10:37 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `darmankadeh`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `add_doctor` (IN `Username` VARCHAR(20), IN `Password` VARCHAR(20), IN `Name` VARCHAR(20), IN `Spec` VARCHAR(20), IN `Number` VARCHAR(10), IN `Online_pay` BOOLEAN, IN `Experience_years` INT(3), IN `Address` VARCHAR(1000), IN `Phone` VARCHAR(20), IN `Week_days_1` BOOLEAN, IN `Week_days_2` BOOLEAN, IN `Week_days_3` BOOLEAN, IN `Week_days_4` BOOLEAN, IN `Week_days_5` BOOLEAN, IN `Week_days_6` BOOLEAN, IN `Week_days_7` BOOLEAN)  NO SQL
begin
if not EXISTS(select * from doctor where UPPER(doctor.username) = UPPER(UserName) or doctor.number = Number or doctor.phone= Phone)
then
	begin
   	 	if length(Password) >5
        THEN
        begin
        	if  length(UserName)> 5
            THEN
            BEGIN
            	INSERT INTO doctor (username,password,name,spec,number,online_pay,experience_years,address,phone,week_days_1,week_days_2,week_days_3,week_days_4,week_days_5,week_days_6,week_days_7)
				values(Username,md5(Password),Name,Spec,Number,Online_pay,Experience_years,Address,Phone,Week_days_1,Week_days_2,Week_days_3,Week_days_4,Week_days_5,Week_days_6,Week_days_7);
				select 'you have signed up successfully';
			end;
			else
				begin
					select 'username length should be more than 5';
				end;


            end if;
		end;
		else
			begin
				select 'password length should be more than 5';
			end;

        end if;
	end;
	else
		begin
			select 'doctor already exist';
		end;

    end if;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `add_patient` (IN `UserName` VARCHAR(20), IN `Password` VARCHAR(20), IN `Phone` VARCHAR(20))  NO SQL
begin
if not EXISTS(select * from patient where UPPER(patient.username) = UPPER(UserName))
then
	begin
   	 	if length(Password) >5
        THEN
        begin
        	if  length(UserName)> 5
            THEN
            BEGIN
            	INSERT INTO patient (username,password,phone)
				values(UserName, md5(Password),Phone);
				select 'you have signed up successfully';
			end;
			else
				begin
					select 'username length should be more than 5';
				end;


            end if;
		end;
		else
			begin
				select 'password length should be more than 5';
			end;

        end if;
	end;
	else
		begin
			select 'user already exist';
		end;

    end if;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `comment` (IN `d_username` VARCHAR(20), IN `p_username` VARCHAR(20), IN `text` VARCHAR(1000))  NO SQL
begin
		INSERT INTO 		  comments(doctor_username,patient_username,comment,time)

	VALUES(d_username,p_username,text,current_timestamp());

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `edit_patient` (IN `UserName` VARCHAR(20), IN `Password` VARCHAR(20), IN `Phone` VARCHAR(20))  NO SQL
begin

UPDATE patient
SET
patient.password = md5(Password),
patient.phone=Phone

WHERE patient.username = Username;

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `login_doctor` (IN `UserName` VARCHAR(20), IN `Password` VARCHAR(20))  NO SQL
begin
if not EXISTS(select * from doctor where UPPER(doctor.username) = UPPER(Username) and doctor.password= md5(Password))
then
	begin
		select 'username or password incorrect try again';

	end;
	else
		begin
			select 'You have successfully loged in';
			INSERT INTO doctor_logs(username,time)
			SELECT * FROM (SELECT Username,current_timestamp()) AS tmp
			WHERE Username In (
			SELECT doctor.username FROM doctor WHERE  UPPER(doctor.username) = UPPER(Username) and doctor.password= md5(Password)
			);

		end;

    end if;


end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `login_patient` (IN `UserName` VARCHAR(20), IN `Password` VARCHAR(20))  NO SQL
begin
if not EXISTS(select * from patient where UPPER(patient.username) = UPPER(Username) and patient.password= md5(Password))
then
	begin
		select 'username or password incorrect try again';

	end;
	else
		begin
			select 'You have successfully loged in';
			INSERT INTO patient_logs(username,time)
			SELECT * FROM (SELECT Username,current_timestamp()) AS tmp
			WHERE Username In (
			SELECT patient.username FROM patient WHERE  UPPER(patient.username) = UPPER(Username) and patient.password= md5(Password)
			);

		end;

    end if;


end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `rate` (IN `d_username` VARCHAR(20), IN `p_username` VARCHAR(20), IN `r` INT(1))  NO SQL
begin
		INSERT INTO 		  rates(doctor_username,patient_username,rate)

	VALUES(d_username,p_username,r);

end$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `search_doctor` (IN `Name` VARCHAR(20))  NO SQL
select * from doctor WHERE doctor.name like (Select CONCAT ("%",Name,"%"))$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `spec_list` (IN `Spec` VARCHAR(20))  NO SQL
select * from doctor where doctor.spec = Spec$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `doctor_username` varchar(20) NOT NULL,
  `patient_username` varchar(20) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`doctor_username`, `patient_username`, `comment`, `time`) VALUES
('mohammad', 'newsha', 'test comment ', '2021-02-05 21:31:02');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `spec` varchar(20) NOT NULL,
  `number` varchar(10) NOT NULL,
  `online_pay` tinyint(1) NOT NULL,
  `experience_years` int(3) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `week_days_1` tinyint(1) NOT NULL,
  `week_days_2` tinyint(1) NOT NULL,
  `week_days_3` tinyint(1) NOT NULL,
  `week_days_4` tinyint(1) NOT NULL,
  `week_days_5` tinyint(1) NOT NULL,
  `week_days_6` tinyint(1) NOT NULL,
  `week_days_7` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`username`, `password`, `name`, `spec`, `number`, `online_pay`, `experience_years`, `address`, `phone`, `week_days_1`, `week_days_2`, `week_days_3`, `week_days_4`, `week_days_5`, `week_days_6`, `week_days_7`) VALUES
('ali_123', '123456', 'ali', 'qwer', '12345', 1, 5, 'dsfsdtm', '0978787878', 0, 0, 0, 0, 0, 0, 0),
('ali_3214', '123487', 'aliakbar', 'sdfgh', '12387', 1, 8, 'dsfsdtm', '09121212121', 0, 0, 0, 0, 0, 0, 0),
('ali_98765', '123487', 'mohammad ali', 'drty', '74185', 0, 5, 'tghjkl;k', '09827193', 0, 0, 0, 0, 0, 0, 0),
('mohammad', '987654', 'mohammad alavi', 'sdfgh', '98678', 0, 44, 'qwertfcdxsa', '0974747474', 0, 0, 0, 0, 0, 0, 0),
('Newsha', '968574', 'Newsha Shahbodagh', 'Heart', '123456', 1, 20, 'wertyui', '09874563', 1, 1, 1, 0, 0, 1, 1),
('Hossein_123', '987654', 'Hossein sharafi', 'Heart', '78451', 1, 12, 'wertyuio', '0985\\', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_logs`
--

CREATE TABLE `doctor_logs` (
  `username` varchar(20) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`username`, `password`, `phone`) VALUES
('newsha', '6ebe76c9fb411be97b3b', '0987654321');

-- --------------------------------------------------------

--
-- Table structure for table `patient_logs`
--

CREATE TABLE `patient_logs` (
  `username` varchar(20) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rates`
--

CREATE TABLE `rates` (
  `doctor_username` varchar(20) NOT NULL,
  `patient_username` varchar(20) NOT NULL,
  `rate` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rates`
--

INSERT INTO `rates` (`doctor_username`, `patient_username`, `rate`) VALUES
('mohammad', 'newsha', 5);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

