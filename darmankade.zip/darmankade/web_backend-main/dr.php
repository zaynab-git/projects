<?php 
  session_start(); 

  if (!isset($_SESSION['dr'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: dr_log_in.php');
  }
  if (isset($_GET['log_out'])) {
  	session_destroy();
  	unset($_SESSION['dr']);
  	header("location: dr_log_in.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="header">
	<h2>Home Page</h2>
</div>
<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['dr'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['dr']; ?></strong></p>
		<p>you are now loged in</p>
		<p> <a href="dr_change_info.php" style="color: red;">change your information</a> </p>
    	<p> <a href="dr.php?log_out='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
</div>
		
</body>
</html>