

<!doctype html>
<html dir="rtl" lang="fa">

<head>
    <title>specialities</title>
    <meta data-n-head="ssr" charset="utf-8">
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1">
    <meta data-n-head="ssr" data-hid="title" name="title" content="درمانکده - مشاوره آنلاین و ویزیت حضوری - آزمایش در محل">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
</head>
<body >

    <!-- توضیحات مربوط به هدر و فوتر در فایل مربوط به لست پزشکان وجود دارد -->
    <header class="navbar navbar-expand-lg navbar-light bg-white" style="font-size: 13px; font-weight: 400; padding: 1rem 10rem; top: 0px; color: #3B4157;">
        
        <a class="navbar-brand" href="#">
            <img src="https://www.darmankade.com/_nuxt/img/cd3eac7.svg" alt="درمانکده">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

    <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="#">
                <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:0;">
                        <line x1="21" y1="10" x2="3" y2="10">
                        </line>
                        <line x1="21" y1="6" x2="3" y2="6">
                        </line>
                        <line x1="21" y1="14" x2="3" y2="14"></line>
                        <line x1="21" y1="18" x2="3" y2="18"></line>
                    </svg>
                    لیست تخصص ها
              </a>
              <div class="drop-down dropdown-menu-right"  style="background-color: white; border-radius: 5px;">
                <div style="width: 100%; text-align: right; display: flex;flex-direction: row; align-items: stretch;">
                    <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/c825bc8.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        گوارش، کبد و آندوسکوپی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMi4yNSIgaGVpZ2h0PSIyOC42ODUiIHZpZXdCb3g9IjAgMCAzMi4yNSAyOC42ODUiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDY4Ljc1IC0xOTUpIj48cmVjdCB3aWR0aD0iMjciIGhlaWdodD0iMjciIHJ4PSIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDc0IDE5NSkiIGZpbGw9IiNmZWUyYmEiLz48cGF0aCBkPSJNMzgwLjA2LDI0MS4yODF2Ljg3NGEyMi4xMDUsMjIuMTA1LDAsMCwxLTIuMDIxLDkuMiwzLjU5MiwzLjU5MiwwLDAsMS0zLjI1MiwyLjA4MSwzLjU1MiwzLjU1MiwwLDAsMS0yLjUzMi0xLjA0OUwzNjkuMiwyNDkuMzNhNS4xODgsNS4xODgsMCwwLDAtNy4zMzgsMGwtMy4wNTYsMy4wNTVhMy41NTYsMy41NTYsMCwwLDEtMi41MzIsMS4wNDksMy41OTIsMy41OTIsMCwwLDEtMy4yNTItMi4wODEsMjIuMTA2LDIyLjEwNiwwLDAsMS0yLjAyMS05LjJ2LS44NzNhMjIuMSwyMi4xLDAsMCwxLDIuMDIxLTkuMiwzLjU4MSwzLjU4MSwwLDAsMSw1Ljc4NC0xLjAzMmwzLjA1NiwzLjA1NmE1LjE5MSw1LjE5MSwwLDAsMCw3LjMzOCwwbDMuMDU2LTMuMDU2YTMuNTgsMy41OCwwLDAsMSw1Ljc4MywxLjAzMkEyMi4wOSwyMi4wOSwwLDAsMSwzODAuMDYsMjQxLjI4MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcxOC41IC0zMC41KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMTc4MGRmIiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS13aWR0aD0iMS41Ii8+PC9nPjwvc3ZnPg==" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        غدد و متابولیسم
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/09709b8.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        گوش ،حلق و بینی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/42073bf.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        مغز و اعصاب
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/0fa4e19.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        خون و آنکولوژی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/4b862e5.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        زنان و زایمان
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                    </div>
                    <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/d25b940.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                       پوست و مو
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/33fe84f.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        روماتولوژی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/4e329ca.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        جراحی مغز و اصاب
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/6deb567.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        روانپزشکی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/bbb08de.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                       اورتوپدی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                
                        <button style="margin-bottom: 1rem; margin-right: 1rem;">
                            مشاهده همه
                            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                <polyline points="15 18 9 12 15 6"    >
                                </polyline>
                            </svg>
                        </button>
                    </div>
                    <img src="https://www.darmankade.com/_nuxt/img/8d6a3eb.png" alt="از بهترین پزشکان تهران آنلاین نوبت بگیرید!" style="width: 35%; height: auto; flex-grow: 1;">
                </div>
            </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-0 dr-menu__icon feather feather-wifi">
                        <path d="M5 12.55a11 11 0 0 1 14.08 0">
                        </path>
                        <path d="M1.42 9a16 16 0 0 1 21.16 0">
                        </path>
                        <path d="M8.53 16.11a6 6 0 0 1 6.95 0">
                        </path>
                        <line x1="12" y1="20" x2="12" y2="20"></line>
                    </svg>
                    لیست مشاوره آنلاین
                </a>
                <div class=" dropdown-menu-right drop-down">
                    <div style="width: 100%; background-color: white; margin: auto; text-align: right;border-radius: 15px; display: flex;flex-direction: row; align-items: stretch;">
                        <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/bbb0bf5.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                           روانشناس
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/4b862e5.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            زنان و زایمان
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMi4yNSIgaGVpZ2h0PSIyOC42ODUiIHZpZXdCb3g9IjAgMCAzMi4yNSAyOC42ODUiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDY4Ljc1IC0xOTUpIj48cmVjdCB3aWR0aD0iMjciIGhlaWdodD0iMjciIHJ4PSIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDc0IDE5NSkiIGZpbGw9IiNmZWUyYmEiLz48cGF0aCBkPSJNMzgwLjA2LDI0MS4yODF2Ljg3NGEyMi4xMDUsMjIuMTA1LDAsMCwxLTIuMDIxLDkuMiwzLjU5MiwzLjU5MiwwLDAsMS0zLjI1MiwyLjA4MSwzLjU1MiwzLjU1MiwwLDAsMS0yLjUzMi0xLjA0OUwzNjkuMiwyNDkuMzNhNS4xODgsNS4xODgsMCwwLDAtNy4zMzgsMGwtMy4wNTYsMy4wNTVhMy41NTYsMy41NTYsMCwwLDEtMi41MzIsMS4wNDksMy41OTIsMy41OTIsMCwwLDEtMy4yNTItMi4wODEsMjIuMTA2LDIyLjEwNiwwLDAsMS0yLjAyMS05LjJ2LS44NzNhMjIuMSwyMi4xLDAsMCwxLDIuMDIxLTkuMiwzLjU4MSwzLjU4MSwwLDAsMSw1Ljc4NC0xLjAzMmwzLjA1NiwzLjA1NmE1LjE5MSw1LjE5MSwwLDAsMCw3LjMzOCwwbDMuMDU2LTMuMDU2YTMuNTgsMy41OCwwLDAsMSw1Ljc4MywxLjAzMkEyMi4wOSwyMi4wOSwwLDAsMSwzODAuMDYsMjQxLjI4MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcxOC41IC0zMC41KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMTc4MGRmIiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS13aWR0aD0iMS41Ii8+PC9nPjwvc3ZnPg==" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            غدد و متابولیسم
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/6ebe09c.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            کودکان
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/614597c.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            گوارش، کبد و آندوسکوپی
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <button style="margin-bottom: 1rem; margin-right: 1rem;" >
                                مشاوره آنلاین فوری
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                    <polyline points="15 18 9 12 15 6"    >
                                    </polyline>
                                </svg>
                            </button>
                        </div>
                        <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/6deb567.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            روانپزشک
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/3a03010.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                           بیماری های عفونی و تبدار
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/d25b940.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            پوست و مو
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/f03344c.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            کلیه و مجاری ادراری
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/09709b8.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            گوش، حلق و بینی
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            
                            <button style="margin-bottom: 1rem; margin-right: 1rem;" >
                                مشاهده همه
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                    <polyline points="15 18 9 12 15 6"    >
                                    </polyline>
                                </svg>
                            </button>
                        </div>
                        <img src="https://www.darmankade.com/_nuxt/img/1d6b04b.png" alt="از بهترین پزشکان تهران آنلاین نوبت بگیرید!" style="width: 35%; height: auto; flex-grow: 1;">
                    </div>
                </div>
                
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dr-menu__icon feather feather-book"    >
                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"    >
                        </path>
                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"    >
                        </path>
                    </svg>
                    <span class="text-14"  >
                        مجله پزشکی 
                   </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dr-menu__icon feather feather-user-plus"  >
                        <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"  ></path>
                        <circle cx="8.5" cy="7" r="4"  ></circle>
                        <line x1="20" y1="8" x2="20" y2="14"  ></line>
                        <line x1="23" y1="11" x2="17" y2="11"  ></line>
                    </svg> 
                    <span class="text-14"  >
                     عضویت پزشکان 
                    </span>
                </a>
            </li>
            <li class="nav-item" style="padding-left: 12rem;">
                <a class="nav-link" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dr-menu__icon feather feather-box"    >
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"    ></path>
                        <polyline points="3.27 6.96 12 12.01 20.73 6.96"    ></polyline>
                        <line x1="12" y1="22.08" x2="12" y2="12"    ></line>
                    </svg>
                    <span class="text-14"  >
                        کرونا سازمانی 
                    </span> 
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link enter enter border-0 text-16 ml-2 bg-transparent bg-white"  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"    >
                        <circle cx="11" cy="11" r="8"    ></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"    ></line>
                    </svg>
                </a>
            </li>
            <li class="nav-item">    
                <div style=" border-radius: 5px; text-align: center; padding: 0rem 0.3rem; background-color: #EDEDED;">
                        <a href="login.html" class="nav-link enter">
                        ورود
                        <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"  ></path>
                            <polyline points="10 17 15 12 10 7"  ></polyline>
                            <line x1="15" y1="12" x2="3" y2="12"  ></line>
                        </svg>
                    </a> 
                </div>   
            </li>
        </ul>
    </div>
</header>


<!-- این بخش یک کروسل است که شامل 2 تصویر است که خود به خود پس از مدتی تغییر می کنند -->


<!-- بخش اصلی سایت که حاوی اسلاید بار و اطلاهات هر بیماری است -->
<section style="width: 80%; margin: auto;">
    
    <!-- این بخش شامل 2 ستون است -->
    <div class="row py-4 pr-3"    >
        <!-- ستون اول -->
        <div class="px-0 col-md-5 col-lg-3"    >
            <!-- پوزیشن این بخش فیکس است و با حرکت به پایین صفحه ثابت میماند -->
            <aside class="position-sticky fixed-top w-100"  >
                <div class="card rounded-10"    >
                    <!-- بخش بالایی یا تیتر کارت -->
                    <div class="row align-items-center p-3 border-bottom "    >
                        <svg style="margin-right: 0.5rem;" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="ml-3 text-slate feather feather-align-right"    >
                            <line x1="21" y1="10" x2="7" y2="10"    ></line>
                            <line x1="21" y1="6" x2="3" y2="6"    ></line>
                            <line x1="21" y1="14" x2="3" y2="14"    ></line>
                            <line x1="21" y1="18" x2="7" y2="18"    ></line>
                        </svg> 
                        <h5 class="text-slate mb-0 ml-2 font-weight-bold" style="font-size: 16px;">
                            همه تخصص ها
                        </h5> 
                        <span style="font-size: 13px; color: gray;"> (به ترتیب حروف الفبا) </span>
                    </div> 
                    
                    <!-- بخش داخلی کارت که شامل سرچ و تخصص ها است و قابل اسکرول کردن است -->
                    <div class=" my-custom-scrollbar" style="height: 38rem;" >
                        
                        <!-- قسمت سرچ -->
                        <div class="card-body px-0 position-relative mt-1 ml-2 mr-2" style="border-radius: 0.5rem;">
                            <svg style="color:  #1780DF;" xmlns="http://www.w3.org/2000/svg" width="1.2em" height="1.2em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mt-2 mr-2 position-absolute search-icon text-steel feather feather-search"    >
                                <circle cx="11" cy="11" r="8"    ></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"    ></line>
                            </svg>
                            <input type="text" name="search" placeholder="تخصص مورد نظر خود را جستجو کنید." value="" class="border p-2 bg-light w-100 pr-5" style="font-size: 12px; border-radius: 0.5rem;"> 
                            
                        </div>
                        <!-- لیست تخصص ها -->
                       <ul class="sickness_list" style="list-style-type: none; text-align: right; font-size: 16px; padding-right: 1rem;">
                            <li>
                                <div style="border-radius: 0.2rem; text-align: center; width: 2.2rem; height: 2.2rem; background-color: #E5F2FE;">
                                    <p>پ</p>
                                </div>
                            </li>
                            <li>
                                <a href="#" >پوست</a>
                            </li>
                            <li>
                                <a href="#" >پیوند کلیه</a>
                            </li>
                            <li>
                                <div style="border-radius: 0.2rem; text-align: center; width: 2.2rem; height: 2.2rem; background-color: #E5F2FE;">
                                    <p>چ</p>
                                </div>
                            </li>
                            <li>
                                <a href="#" >چشم</a>
                            </li>
                            <li>
                                <div style="border-radius: 0.2rem; text-align: center; width: 2.2rem; height: 2.2rem; background-color: #E5F2FE;">
                                    <p>د</p>
                                </div>
                            </li>
                            <li>
                                <a href="#" >داخلی</a>
                            </li>
                            <li>
                                <a href="#" >درد</a>
                            </li>
                            <li>
                                <a href="#" ">دیابت</a>
                            </li>
                            <li>
                                <a href="#" >دندانپزشکی</a>
                            </li>
                            <li>
                                <div style="border-radius: 0.2rem; text-align: center; width: 2.2rem; height: 2.2rem; background-color: #E5F2FE;">
                                    <p>ز</p>
                                </div>
                            </li>
                            <li>
                                <a href="#" >زانو</a>
                            </li>
                            <li>
                                <a href="#">زنان زایمان</a>
                            </li>
                            <li>
                                <div style="border-radius: 0.2rem; text-align: center; width: 2.2rem; height: 2.2rem; background-color: #E5F2FE;">
                                    <p>ط</p>
                                </div>
                            </li>
                            <li>
                                <a href="#" >طب اورژانس</a>
                            </li>
                            <li>
                                <a href="#">طب خواب</a>
                            </li>
                            <li>
                                <a href="#">طب سوزنی</a>
                            </li>
                            
                       </ul>
                    </div>

                    <!-- بخش اسکرول کنید -->
                    <div class="btn-scroll position-sticky text-center align-items-center p-2 w-100 rounded-bottom-10" style="border-radius:0 0 0.5rem 0.5rem; bottom:0;right:0; background-color: #E5F2FE; color: #1780DF;"  >
                        اسکرول کنید
                        <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevrons-down"    >
                            <polyline points="7 13 12 18 17 13"    ></polyline>
                            <polyline points="7 6 12 11 17 6"    ></polyline>
                        </svg>
                    </div>
                </div>
            </aside>
        </div> 

        <!-- ستون دوم -->
        <!-- این بخش شامل 9 تخصص است و هر تخصص تقریبا یک سوم فضای سطر را اشغال می کند -->
        <div class="px-0 pr-md-3 row col-md-7 col-lg-9 col-12"    >
            <div class="px-0 mb-3 col-md-6 col-lg-4 col-12 px-md-3"    >
                <!-- هر بیماری یک لینک است و شامل 3 ردیف است -->
                <div class="card rounded-10 hover-melon h-100 p-3"      >
                    <a href="DRs_list.html"   class="text-decoration-none sickness-card" style="color: black;">
                        <!-- ردیف اول حاوی تصویر و اسم بیماری است -->
                        <div class="row align-items-center mb-4"  >
                            <img src="https://www.darmankade.com/_nuxt/img/f5ffb82.svg" alt="گوارش و کبد" title="گوارش و کبد" class="w-25 dr-degree__image pr-2"  > 
                            <h5 class="font-weight-bold text-18 text-right w-75 text-slate pr-3 mb-0 line-height-30"  >
                                قلب
                            </h5>
                        </div> 
                        <!-- ردیف دوم توضیحات بیماری است -->
                        <p class="text-justify mb-4 line-height-26" style="font-size: 13px; color: gray; line-height: 1.7rem;">
                            متخصص گوارش، کبد و آندوسکوپی پزشکی که بر سلامت گوارش تمرکز دارد و در زمینه تشخیص، ارزیابی و درمان اختلالا
                        </p> 
                        <!-- ردیف سوم تعداد پزشکان و اعکسی از 3 تا از آنها و دکمه است -->
                        <div class="row"  >
                            <div style="margin-right: 1rem;">
                                <img src="https://www.darmankade.com/UploadFiles/Doctor/131900288330649685%D8%AF%DA%A9%D8%AA%D8%B1-%D8%A8%D9%87%D8%B1%D8%A7%D9%85-%D9%87%D8%A7%D8%B4%D9%85%DB%8C.jpg" alt="بهرام هاشمی" class=" rounded-circle " style="width: 2rem;">
                                <img src="https://www.darmankade.com/UploadFiles/Doctor/131897014023446353%D8%AF%DA%A9%D8%AA%D8%B1-%D8%BA%D9%84%D8%A7%D9%85%D8%AD%D8%B3%DB%8C%D9%86-%D9%81%D9%84%D8%A7%D8%AD%DB%8C.jpg" alt="غلامحسین فلاحی" class="dr-img rounded-circle absolute-img1" style="width: 2rem; margin-right: -0.7rem;">
                                <img src="https://www.darmankade.com/UploadFiles/Doctor/131630023467399423%D8%AF%DA%A9%D8%AA%D8%B1-%DA%A9%D8%B1%D8%A8%D8%A7%D8%B3%DB%8C%20(1).jpg" alt="دکتر کرباسی" class="dr-img rounded-circle absolute-img2"style="width: 2rem; margin-right: -0.7rem; "> 
                                <p class="d-block mt-1 mb-0 text-center font-weight-boldw-70" style="font-size: 10px; font-weight: bolder;">
                                     + 132 پزشک
                                </p>
                            </div> 
                            <!-- دکمه ی مشاهده بیشتر -->
                            <a href="DRs_list.php?spec=3" style="font-size: small; font-weight: bolder;  margin-right: 2rem; padding: 0 1rem;" >
                                مشاهده
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                    <line x1="19" y1="12" x2="5" y2="12"  ></line>
                                    <polyline points="12 19 5 12 12 5"  ></polyline>
                                </svg>
                            </a>
                    </div>
                </a><!----><!---->
            </div>
        </div>
        <div class="px-0 mb-3 col-md-6 col-lg-4 col-12 px-md-3"    >
            <div class="card rounded-10 hover-melon h-100 p-3"      >
                <a href="DRs_list.html"   class="text-decoration-none sickness-card" style="color: black;">
                    <div class="row align-items-center mb-4"  >
                        <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2NSIgaGVpZ2h0PSI2NSIgdmlld0JveD0iMCAwIDY1IDY1Ij4NCiAgPGcgaWQ9Ikdyb3VwXzQ0MjM5IiBkYXRhLW5hbWU9Ikdyb3VwIDQ0MjM5IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgzMjM3IDQzNDMpIj4NCiAgICA8cmVjdCBpZD0iUmVjdGFuZ2xlXzU1MTQiIGRhdGEtbmFtZT0iUmVjdGFuZ2xlIDU1MTQiIHdpZHRoPSI2NSIgaGVpZ2h0PSI2NSIgcng9IjUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0zMjM3IC00MzQzKSIgZmlsbD0iI2M1ZTFmYiIvPg0KICAgIDxwYXRoIGlkPSJQYXRoXzI5ODYzIiBkYXRhLW5hbWU9IlBhdGggMjk4NjMiIGQ9Ik0zODguMjI4LDI0NC40NTJ2MS4xMTlhMjguMzE5LDI4LjMxOSwwLDAsMS0yLjU4OCwxMS43ODYsNC42LDQuNiwwLDAsMS00LjE2NywyLjY2NSw0LjU1MSw0LjU1MSwwLDAsMS0zLjI0My0xLjM0NGwtMy45MTUtMy45MTRhNi42NDcsNi42NDcsMCwwLDAtOS40LDBMMzYxLDI1OC42NzlhNC41NTYsNC41NTYsMCwwLDEtMy4yNDQsMS4zNDMsNC42LDQuNiwwLDAsMS00LjE2Ni0yLjY2NUEyOC4zMiwyOC4zMiwwLDAsMSwzNTEsMjQ1LjU3di0xLjExOGEyOC4zMTMsMjguMzEzLDAsMCwxLDIuNTg4LTExLjc4Niw0LjU4Nyw0LjU4NywwLDAsMSw3LjQxLTEuMzIybDMuOTE1LDMuOTE1YTYuNjUsNi42NSwwLDAsMCw5LjQsMGwzLjkxNS0zLjkxNWE0LjU4Niw0LjU4NiwwLDAsMSw3LjQwOSwxLjMyMkEyOC4zLDI4LjMsMCwwLDEsMzg4LjIyOCwyNDQuNDUyWiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTM1NzQuNSAtNDU1NS4wODcpIiBmaWxsPSIjNTdhYmY4IiBzdHJva2U9IiMzYjQxNTciIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLXdpZHRoPSIyIi8+DQogIDwvZz4NCjwvc3ZnPg0K" alt="گوارش و کبد" title="گوارش و کبد" class="w-25 dr-degree__image pr-2"  > 
                        <h5 class="font-weight-bold text-18 text-right w-75 text-slate pr-3 mb-0 line-height-30"  >
                            مغز
                        </h5>
                    </div> 
                    <p class="text-justify mb-4 line-height-26" style="font-size: 13px; color: gray; line-height: 1.7rem;">
                        متخصص غدد و متابولیسم پزشکی است که بیماری‌های هورمونی را به طور کامل مطالعه کرده و بهترین درمان‌های ممکن ...

                    </p> 
                    <div class="row"  >
                        <div style="margin-right: 1rem;">
                            <img src="https://www.darmankade.com/UploadFiles/Doctor/131899429089629661%D8%AF%DA%A9%D8%AA%D8%B1-%D9%86%D8%A7%D9%87%DB%8C%D8%AF-%D8%AE%D9%84%DB%8C%D9%84%DB%8C.jpg" alt="بهرام هاشمی" class=" rounded-circle " style="width: 2rem;">
                            <img src="https://www.darmankade.com/UploadFiles/Doctor/131906278987061881%D8%AF%DA%A9%D8%AA%D8%B1-%D9%85%D8%B1%DB%8C%D9%85-%D8%A7%D8%B1%D8%AF%D8%B4%DB%8C%D8%B1%DB%8C.jpg" alt="غلامحسین فلاحی" class="dr-img rounded-circle absolute-img1" style="width: 2rem; margin-right: -0.7rem;">
                            <img src="https://www.darmankade.com/UploadFiles/Doctor/131884182637775418photo_2018-04-19_17-14-04.jpg" alt="دکتر کرباسی" class="dr-img rounded-circle absolute-img2"style="width: 2rem; margin-right: -0.7rem; "> 
                            <p class="d-block mt-1 mb-0 text-center font-weight-boldw-70" style="font-size: 10px; font-weight: bolder;">
                                 + 73 پزشک
                            </p>
                        </div> 
                        <a href="DRs_list.php?spec=1" style="font-size: small; font-weight: bolder;  margin-right: 2rem; padding: 0 1rem;" >
                                مشاهده
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                    <line x1="19" y1="12" x2="5" y2="12"  ></line>
                                    <polyline points="12 19 5 12 12 5"  ></polyline>
                                </svg>
                            </a>
                </div>
            </a><!----><!---->
        </div>
    </div>
    <div class="px-0 mb-3 col-md-6 col-lg-4 col-12 px-md-3"    >
        <div class="card rounded-10 hover-melon h-100 p-3"      >
            <a href="DRs_list.html"   class="text-decoration-none sickness-card" style="color: black;">
                <div class="row align-items-center mb-4"  >
                    <img src="https://www.darmankade.com/_nuxt/img/126376d.svg" alt="گوارش و کبد" title="گوارش و کبد" class="w-25 dr-degree__image pr-2"  > 
                    <h5 class="font-weight-bold text-18 text-right w-75 text-slate pr-3 mb-0 line-height-30"  >
                        روماتولوژی
                    </h5>
                </div> 
                <p class="text-justify mb-4 line-height-26" style="font-size: 13px; color: gray; line-height: 1.7rem;">
                    پزشکی که در زمینه تشخیص، مراقبت‌های پزشکی، جراحی و درمان بیمارانی که دچار اختلالات گوش، بینی، دهان، گلو، ...
                </p> 
                <div class="row"  >
                    <div style="margin-right: 1rem;">
                        <img src="https://www.darmankade.com/UploadFiles/Doctor/131900324745298938%D8%AF%DA%A9%D8%AA%D8%B1-%D8%A7%D8%B5%D8%BA%D8%B1-%D8%A7%D8%AE%D9%88%D8%A7%D9%86.jpg" alt="بهرام هاشمی" class=" rounded-circle " style="width: 2rem;">
                        <img src="https://www.darmankade.com/UploadFiles/Doctor/132386637085048934WhatsApp%20Image%202020-07-08%20at%2010.44.53.jpeg" alt="غلامحسین فلاحی" class="dr-img rounded-circle absolute-img1" style="width: 2rem; margin-right: -0.7rem;">
                        <img src="https://www.darmankade.com/UploadFiles/Doctor/132403148660992209alireza-safaie.png" alt="دکتر کرباسی" class="dr-img rounded-circle absolute-img2"style="width: 2rem; margin-right: -0.7rem; "> 
                        <p class="d-block mt-1 mb-0 text-center font-weight-boldw-70" style="font-size: 10px; font-weight: bolder;">
                             + 56 پزشک
                        </p>
                    </div> 
                    <a href="DRs_list.php?spec=2" style="font-size: small; font-weight: bolder;  margin-right: 2rem; padding: 0 1rem;" >
                                مشاهده
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                    <line x1="19" y1="12" x2="5" y2="12"  ></line>
                                    <polyline points="12 19 5 12 12 5"  ></polyline>
                                </svg>
                            </a>
            </div>
        </a><!----><!---->
    </div>
</div>


    </div>                
     
    
</section>



<!-- توضیحات مربوط به هدر و فوتر در فایل مربوط به لیست پزشکان موجود است -->
    <footer style="background-color: #1780DF;">
        <div style="width: 80%; padding: 2rem 0; margin: auto;">
            <div class="container"  >
                <div class="row"  >
                    <div class="col-4"  >
                        <a href="#" title="صفحه اصلی" class="w-100" style="margin-left: 12rem;">
                            <img src="https://www.darmankade.com/_nuxt/img/7bbb5c4.svg" alt="درمانکده"  >
                        </a> 
                        <p class="text-justify text-white col-10 px-0 d-block w-100 float-right pt-3 text-14 mb-0 line-height-30" style="line-height: 30px"  >
                             درمانکده، ارائه دهنده خدمات آنلاین سلامت
                            (نوبت گیری اینترنتی، مشاوره آنلاین، آزمایش در محل و ...)
                        </p>
                    </div> 
                    <div class="col-4 align-self-center"  >
                        <div class="row"  >
                            <div class="col-6"  >
                                <ul class="list-unstyled mb-0 pr-0 text-right"  >
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                             سوالات
                                            متداول
                                        </a>
                                    </li> 
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                            قوانین و
                                            مقررات
                                        </a>
                                    </li> 
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                        شکایت
                                        </a>
                                    </li>
                                </ul>
                            </div> 
                            <div class="col-6"  >
                                <ul class="list-unstyled mb-0 pr-0 text-white text-center"  >
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                            درباره درمانکده
                                        </a>
                                    </li> 
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                            تماس با
                                            ما
                                        </a>
                                    </li> 
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >مجله پزشکی</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div> 
                    <div class="col-4"  >
                        <div class="row text-center justify-content-center"  >
                            <div class=" bg-white col-4 ml-3" style="border-radius: 2rem;">
                                <img alt="logo-samandehi" src="img/img1.png" class="w-100 h-auto" >
                            </div> 
                            <div class=" bg-white col-4" style="border-radius: 2rem;"e>
                                <a target="_blank" href="https://trustseal.enamad.ir/?id=107984&Code=TIxyyDUwLE22aX96fu2X"  >
                                    <img src="img/img2.png" alt="enamad" class="w-100 h-auto rounded-10" ></a>
                            </div> 
                            <div  >
                                    <ul class="list-inline list-unstyled mt-4 row px-4 mb-0"  >
                                        <li class=" ml-5"  >
                                            <a  href="https://www.instagram.com/darmankade/" target="_blank"  >
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-white px-1 feather feather-instagram"    >
                                                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"    ></rect>
                                                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"    ></path>
                                                    <line x1="17.5" y1="6.5" x2="17.5" y2="6.5"    ></line>
                                                </svg>
                                            </a>
                                        </li> 
                                        <li class="social"  >
                                            <a href="https://twitter.com/darmankade" target="_blank"  >
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-white px-1 feather feather-twitter"    >
                                                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"    ></path>
                                                </svg>
                                            </a>
                                        </li> 
                                        <li class="social mr-5"  ><a href="https://www.linkedin.com/company/darmankade.ir/" target="_blank"  >
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-white px-1 feather feather-linkedin"    >
                                                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"    ></path>
                                                <rect x="2" y="9" width="4" height="12"    ></rect>
                                                <circle cx="4" cy="4" r="2"    ></circle>
                                            </svg>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        <div class="container-fluid bg-white"  >
            <div class="container"  >
                <div class="row justify-content-between align-self-center py-2"  >
                    <p class="text-slate text-12 mb-0"  >
                        تمامی حقوق این سایت برای درمانکده محفوظ است
                    </p> 
                    <p class="text-slate text-12 mb-0"  >
                        طراحی شده با 
                        <span  >
                            <svg style="color: red;" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-fill-red feather feather-heart"    >
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"    ></path>
                            </svg> 
                            توسط تیم درمانکده 
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </footer>



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>

</body>
</html>