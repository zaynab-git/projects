<?php include('search_dr.php') ?>
<!doctype html>
<html dir="rtl" lang="fa">

<head>
    <title>home</title>
    <meta data-n-head="ssr" charset="utf-8">
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1">
    <meta data-n-head="ssr" data-hid="title" name="title"
          content="درمانکده - مشاوره آنلاین و ویزیت حضوری - آزمایش در محل">
    <meta data-n-head="ssr" property="og:image"
          content="https://admin.darmankade.com/UploadFiles/image/Blog-darmankade-logo.png">
    <link data-n-head="ssr" rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="stylesheet" href="style3.css">
</head>
<body>
<!--main header of each page-->
<header>

    <div style="display: flex;flex-direction: row; align-items: stretch; width: 97%; margin: auto;">
        <div style="margin: auto; width: 15%; flex-grow: 1;">
            <a href="#" aria-current="page">
                <img src="https://www.darmankade.com/_nuxt/img/cd3eac7.svg" alt="درمانکده">
            </a>
        </div>
        <div style="text-align: center; width: 70%; display: flex; margin: auto; padding-top: 1rem; flex-grow: 8;">
            <div class="nav-item">
                <div style="text-align: center;">
                    <a href="#" class="nav_element">
                        <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24"
                             fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                             stroke-linejoin="round" style="margin-right:0;">
                            <line x1="21" y1="10" x2="3" y2="10">
                            </line>
                            <line x1="21" y1="6" x2="3" y2="6">
                            </line>
                            <line x1="21" y1="14" x2="3" y2="14"></line>
                            <line x1="21" y1="18" x2="3" y2="18"></line>
                        </svg>
                        لیست تخصص ها
                    </a>
                </div>
                <!--                drop down list-->
                <div class="drop-down">
                    <div style="width: 75%; background-color: white; margin: auto; text-align: right;border-radius: 15px; display: flex;flex-direction: row; align-items: stretch;">
                        <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">

                                    <img src="https://www.darmankade.com/_nuxt/img/614597c.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        گوارش، کبد و آندوسکوپی
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMi4yNSIgaGVpZ2h0PSIyOC42ODUiIHZpZXdCb3g9IjAgMCAzMi4yNSAyOC42ODUiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDY4Ljc1IC0xOTUpIj48cmVjdCB3aWR0aD0iMjciIGhlaWdodD0iMjciIHJ4PSIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDc0IDE5NSkiIGZpbGw9IiNmZWUyYmEiLz48cGF0aCBkPSJNMzgwLjA2LDI0MS4yODF2Ljg3NGEyMi4xMDUsMjIuMTA1LDAsMCwxLTIuMDIxLDkuMiwzLjU5MiwzLjU5MiwwLDAsMS0zLjI1MiwyLjA4MSwzLjU1MiwzLjU1MiwwLDAsMS0yLjUzMi0xLjA0OUwzNjkuMiwyNDkuMzNhNS4xODgsNS4xODgsMCwwLDAtNy4zMzgsMGwtMy4wNTYsMy4wNTVhMy41NTYsMy41NTYsMCwwLDEtMi41MzIsMS4wNDksMy41OTIsMy41OTIsMCwwLDEtMy4yNTItMi4wODEsMjIuMTA2LDIyLjEwNiwwLDAsMS0yLjAyMS05LjJ2LS44NzNhMjIuMSwyMi4xLDAsMCwxLDIuMDIxLTkuMiwzLjU4MSwzLjU4MSwwLDAsMSw1Ljc4NC0xLjAzMmwzLjA1NiwzLjA1NmE1LjE5MSw1LjE5MSwwLDAsMCw3LjMzOCwwbDMuMDU2LTMuMDU2YTMuNTgsMy41OCwwLDAsMSw1Ljc4MywxLjAzMkEyMi4wOSwyMi4wOSwwLDAsMSwzODAuMDYsMjQxLjI4MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcxOC41IC0zMC41KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjM2I0MTU3IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS13aWR0aD0iMS41Ii8+PC9nPjwvc3ZnPg0K"
                                         style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        غدد و متابولیسم
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/4c3a371.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        گوش و حلق و بینی
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/4043253.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        مغز و اعصاب
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/4f1af6a.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        خون و آنکولوژی
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                        </div>
                        <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/ebf1db1.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        زنان و زایمان
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/2ac0558.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        پوست و مو
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/d1c0178.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        روماتولوژی
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/5c2b59b.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        جراحی مغز و اعصاب
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/5b92964.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                        روانپزشکی (اعصاب و روان)
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/0290b2a.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                    <span>
                                       ارتوپدی
                                    </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <button class="drop-down-button" ;type="button">
                                مشاهده همه
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                                     fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                     stroke-linejoin="round" class="feather feather-chevron-left"
                                     data-v-68331112>
                                    <polyline points="15 18 9 12 15 6" data-v-68331112>
                                    </polyline>
                                </svg>
                            </button>
                        </div>
                        <img src="https://www.darmankade.com/_nuxt/img/8d6a3eb.png"
                             alt="از بهترین پزشکان تهران آنلاین نوبت بگیرید!"
                             style="width: 55%; height: 50%; flex-grow: 1;">
                    </div>
                </div>
            </div>
            <div class="nav-item">
                <div style="text-align: center;">
                    <a href="#" class="nav_element">
                        <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24"
                             fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                             stroke-linejoin="round" class="mr-0 dr-menu__icon feather feather-wifi">
                            <path d="M5 12.55a11 11 0 0 1 14.08 0">
                            </path>
                            <path d="M1.42 9a16 16 0 0 1 21.16 0">
                            </path>
                            <path d="M8.53 16.11a6 6 0 0 1 6.95 0">
                            </path>
                            <line x1="12" y1="20" x2="12" y2="20"></line>
                        </svg>
                        مشاوره آنلاین
                    </a>
                </div>

                <div class="drop-down">
                    <div style="width: 80%; margin: auto; text-align: right;border-radius: 15px; display: flex;flex-direction: row; align-items: stretch;">
                        <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/c825bc8.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            روانشناسی
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/ebf1db1.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            زنان زایمان و نازایی
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMi4yNSIgaGVpZ2h0PSIyOC42ODUiIHZpZXdCb3g9IjAgMCAzMi4yNSAyOC42ODUiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDY4Ljc1IC0xOTUpIj48cmVjdCB3aWR0aD0iMjciIGhlaWdodD0iMjciIHJ4PSIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDc0IDE5NSkiIGZpbGw9IiNmZWUyYmEiLz48cGF0aCBkPSJNMzgwLjA2LDI0MS4yODF2Ljg3NGEyMi4xMDUsMjIuMTA1LDAsMCwxLTIuMDIxLDkuMiwzLjU5MiwzLjU5MiwwLDAsMS0zLjI1MiwyLjA4MSwzLjU1MiwzLjU1MiwwLDAsMS0yLjUzMi0xLjA0OUwzNjkuMiwyNDkuMzNhNS4xODgsNS4xODgsMCwwLDAtNy4zMzgsMGwtMy4wNTYsMy4wNTVhMy41NTYsMy41NTYsMCwwLDEtMi41MzIsMS4wNDksMy41OTIsMy41OTIsMCwwLDEtMy4yNTItMi4wODEsMjIuMTA2LDIyLjEwNiwwLDAsMS0yLjAyMS05LjJ2LS44NzNhMjIuMSwyMi4xLDAsMCwxLDIuMDIxLTkuMiwzLjU4MSwzLjU4MSwwLDAsMSw1Ljc4NC0xLjAzMmwzLjA1NiwzLjA1NmE1LjE5MSw1LjE5MSwwLDAsMCw3LjMzOCwwbDMuMDU2LTMuMDU2YTMuNTgsMy41OCwwLDAsMSw1Ljc4MywxLjAzMkEyMi4wOSwyMi4wOSwwLDAsMSwzODAuMDYsMjQxLjI4MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcxOC41IC0zMC41KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjM2I0MTU3IiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS13aWR0aD0iMS41Ii8+PC9nPjwvc3ZnPg0K">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            غدد
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/614597c.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            گوارش، کبد و آندوسکوپی
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <button type="button" class="drop-down-button">
                                مشاوره آنلاین فوری
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                                     fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                     stroke-linejoin="round" class="feather feather-chevron-left"
                                     data-v-68331112>
                                    <polyline points="15 18 9 12 15 6" data-v-68331112>
                                    </polyline>
                                </svg>
                            </button>
                        </div>
                        <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/6ebe09c.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            کودکان
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/5b92964.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            روانپزشکی (اعصاب و روان)
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/3a03010.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            بیماری های عفونتی و تب دار
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/2ac0558.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            پوست و مو
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/f03344c.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            کلیه و مجاری ادراری (اورولوژی)
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" style="flex-grow: 1;">
                                <div style=" align-self: center;">
                                    <img src="https://www.darmankade.com/_nuxt/img/4c3a371.svg" style="margin: 0;">
                                    <div style="font-size: 14px; font-weight: bold;">
                                        <span>
                                            گوش و حلق و بینی
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <button type="button" class="drop-down-button" style="margin-right: 10px">
                                مشاهده همه
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
                                     fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                     stroke-linejoin="round" class="feather feather-chevron-left" data-v-68331112
                                >
                                    <polyline points="15 18 9 12 15 6" data-v-68331112>
                                    </polyline>
                                </svg>
                            </button>
                        </div>
                        <img src="https://www.darmankade.com/_nuxt/img/1d6b04b.png"
                             alt="از بهترین پزشکان تهران آنلاین نوبت بگیرید!"
                             style="width: 55%; height: 50%; flex-grow: 1;">
                    </div>
                </div>
            </div>
            <div class="nav-item">
                <div style="text-align: center;">
                    <a href="#" class="nav_element">
                        <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24"
                             fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                             stroke-linejoin="round" class="dr-menu__icon feather feather-book"
                             data-v-49015c94>
                            <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" data-v-49015c94>
                            </path>
                            <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"
                                  data-v-49015c94>
                            </path>
                        </svg>
                        <span class="text-14" data-v-49015c94>
                        عضویت پزشکان
                   </span>
                    </a>
                </div>
            </div>
            <div class="nav-item">
                <div style="text-align: center;">
                    <a href="#" class="nav_element">
                        <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24"
                             fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                             stroke-linejoin="round" class="dr-menu__icon feather feather-user-plus" data-v-49015c94>
                            <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" data-v-49015c94></path>
                            <circle cx="8.5" cy="7" r="4" data-v-49015c94></circle>
                            <line x1="20" y1="8" x2="20" y2="14" data-v-49015c94></line>
                            <line x1="23" y1="11" x2="17" y2="11" data-v-49015c94></line>
                        </svg>
                        <span class="text-14" data-v-49015c94>
                     مجله پزشکی
                    </span>
                    </a>
                </div>
            </div>

            <div class="nav-item">
                <div style="text-align: center;">
                    <a class="nav_element" href="#">
                        <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24"
                             fill="none"
                             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                             class="dr-menu__icon feather feather-box" data-v-49015c94>
                            <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"
                                  data-v-49015c94></path>
                            <polyline points="3.27 6.96 12 12.01 20.73 6.96" data-v-49015c94></polyline>
                            <line x1="12" y1="22.08" x2="12" y2="12" data-v-49015c94></line>
                        </svg>
                        <span class="text-14" data-v-49015c94>
                        کرونا سازمانی
                    </span>
                    </a>
                </div>
            </div>
        </div>
        <div style=" display: flex;flex-direction: row; align-items: stretch; flex-grow: 2; padding-top: 2rem;"
             data-v-49015c94>
            <button type="button" id="showSearch"
                    class="border-0 text-16 ml-2 bg-transparent text-water-blue   bg-white"
                    data-v-49015c94>
                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                     class="feather feather-search" data-v-49015c94>
                    <circle cx="11" cy="11" r="8" data-v-49015c94></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65" data-v-49015c94></line>
                </svg>
            </button>
            <div class="enter" style="text-align: center; padding-right: 1rem;">
                <a href="log_in.php" class="nav_element">
                    ورود کاربران
                </a> <!---->
                <a href="dr_log_in.php" class="nav_element">
                    ورود پزشکان
                </a> <!---->
                <a href="sign_up.php" class="nav_element">
                    ثبت نام کاربران
                </a> <!---->
                <a href="dr_sign_up.php" class="nav_element">
                    ثبت نام پزشکان
                </a> <!---->
            </div>
        </div>
    </div>
</header>
<section>
    <!--    -->
    <div class="consulting"
         style=" padding-top: 2rem; padding-bottom: 2rem; border-radius: 15px; text-align: center; width: 80%;  margin: auto; margin-top: 1rem; background-color: #1780DF; color: white; ">
        <!--        <img src="img/5ef8034.png">-->
        <h1 style="font-size: 2.5rem;">
            <span class="text-white " data-v-f3c85f5c> درمانکده - مشاوره آنلاین و حضوری </span>
        </h1>
        <div class="search-bar">
        <?php include('errors.php'); ?>
        <form action="home.php" method="POST">
        
            <input type="text" placeholder="نام پزشک ، تخصص ، یا محله مورد نظر را جستجو کنید."
                   class="border-0 form-control name px-3 py-4" name="search">
            <div class="col-3 m-0  p-0  " data-v-8ac3cb88>
                <div class="d-flex h-100 cursor-pointer" data-v-8ac3cb88>
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.8em" height="1.8em" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class="pr-2 m-auto text-light-gray-blue custom-class border-right feather feather-map-pin"
                         data-v-8ac3cb88>
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" data-v-8ac3cb88></path>
                        <circle cx="12" cy="10" r="3" data-v-8ac3cb88></circle>
                    </svg>
                    <input type="text" readonly="readonly" placeholder="نام شهر را انتخاب کنید." value="تهران"
                           class="cursor-pointer col city text-steel  border-0 shadow-none pr-3" data-v-8ac3cb88>
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.2em" height="1.2em" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class=" pl-1 m-auto text-light-gray-blue custom-class feather feather-chevron-down"
                         data-v-8ac3cb88>
                        <polyline points="6 9 12 15 18 9" data-v-8ac3cb88></polyline>
                    </svg>
                </div>
            </div>
            <button class="btn px-5 btn-primary  " type="submit" name="search_dr">
                جستجو
            </button>
        </form>
        </div>
    </div>
</section>

<section>
    <div class="best-specialties">
        <div style="flex-grow: 1;">
            <h5 style="font-size: larger; display: inline-block; float: right">
                بهترین تخصص های درمانکده
            </h5>
            <div style="display: inline-block; float: left ; margin-top: 2rem;">
                <a class="seeAll" href="specialities.php" style="font-size: large;">
                    مشاهده همه
                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class="feather feather-chevron-left" data-v-61f52bca>
                        <polyline points="15 18 9 12 15 6" data-v-61f52bca></polyline>
                    </svg>
                </a>
            </div>
        </div>


    </div>
    <div style="  display: flex;flex-direction: row; align-items: stretch; width: 80%; margin: auto; margin-top: 1rem;">
        <div class="card">
            <a href="doctors_List.html">
                <div style="background-color: #e8c9fd;">
                    <img src="https://www.darmankade.com/_nuxt/img/d3ab6b5.png" alt="Avatar"
                         style="display: block; width:40%; margin: auto; padding: 2rem;">
                </div>
                <h3>
                    ارتوپدی
                </h3>
            </a>
        </div>
        <div class="card">
            <a href="doctors_List.html">
                <div style="background-color: #fcbaba;">
                    <img src="https://www.darmankade.com/_nuxt/img/850cd3d.png" alt="Avatar"
                         style="display: block; width:40%; margin: auto; padding: 2rem;">
                </div>
                <h3>
                    اورولوژی
                </h3>
            </a>
        </div>
        <div class="card">
            <a href="doctors_List.html">
                <div style="background-color: #b3e8ca;">
                    <img src="https://www.darmankade.com/_nuxt/img/8a932a4.png" alt="Avatar"
                         style="display: block; width:40%; margin: auto; padding: 2rem;">
                </div>
                <h3>
                    پوست و مو
                </h3>
            </a>
        </div>
        <div class="card">
            <a href="doctors_List.html">
                <div style="background-color: #abc2d8;">
                    <img src="https://www.darmankade.com/_nuxt/img/171ea81.png" alt="Avatar"
                         style="display: block; width:40%; margin: auto; padding: 2rem;">
                </div>
                <h3>
                    زنان و زایمان
                </h3>
            </a>
        </div>
        <div class="card">
            <a href="doctors_List.html">
                <div style="background-color: #fbcbee;">
                    <img src="https://www.darmankade.com/_nuxt/img/f05550d.png" alt="Avatar"
                         style="display: block; width:40%; margin: auto; padding: 2rem;">
                </div>
                <h3>
                    داخلی
                </h3>
            </a>
        </div>
        <div class="card">
            <a href="doctors_List.html">
                <div style="background-color: #C5E1FB;">
                    <img src="https://www.darmankade.com/_nuxt/img/e125f7c.png" alt="Avatar"
                         style="display: block; width:40%; margin: auto; padding: 2rem;">
                </div>
                <h3>
                    گوش، حلق و بینی
                </h3>
            </a>
        </div>

    <div class="card">
        <a href="doctors_List.html">
            <div style="background-color: #fdcdb0;">
                <img src="https://www.darmankade.com/_nuxt/img/838522d.png" alt="Avatar"
                     style="display: block; width:40%; margin: auto; padding: 2rem;">
            </div>
            <h3>
                مغز و اعصاب
            </h3>
        </a>

    </div>

    </div>
</section>
<div class="patient-comments">
    <div class="comment_describe">
        <h3>
            نظرات و روند درمانی بیماران
        </h3>
        <p>
            شما می توانید تجربه مراجعه کاربران دیگر به پزشکان را بخوانید و از علت مراجعه سایر بیماران و روند درمانی آن
            ها آگاهی یابید.
        </p>
    </div>

    <div class="comment">
        <img src="https://www.darmankade.com/_nuxt/img/55d4056.png">
        <p>
            رفتارشون خیلی با بیمار عالی بود و تشخیصشون هم خیلی عالی هست
        </p>
        <div class="triangle">

        </div>
        <div class="row2">
            <div class="dr">
                <img src="https://www.darmankade.com/UploadFiles/Doctor/131897122673087204دکتر-سید-محسن-بهاالدینی.jpg">
                <h4>

                    دکتر سید محسن بها الدینی
                </h4>
                <p>
                    فوق تخصص نوزادان
                </p>

            </div>
            <a href="">
                مشاهده سایر نظرات
            </a>
        </div>


    </div>


</div>
<div class="special-services">
    <div class=row1>
        <p>
            نگران کرونا نباشید
        </p>
    </div>
    <div class="prcTest">
        <img src="https://www.darmankade.com/_nuxt/img/994ebdc.png">
        <h4>تست PCR و آنتی بادی در محل</h4>
        <p>اگر در شهرهای تهران، مشهد، اصفهان، کرج، شیراز و اهواز هستید، می‌توانید بدون مراجعه به آزمایشگاه و در محل
            مدنظر خود آزمایش کرونا بدهید.</p>
        <a href="">
            <!--            درخواست آزمایش   &gt;-->
            درخواست آزمایش &nbsp;&nbsp;&nbsp;&gt;
        </a>
    </div>
    <div class="online-consulting">
        <img src="https://www.darmankade.com/_nuxt/img/4126cda.png">
        <h4>
            مشاوره آنلاین فوری
        </h4>
        <p>
            با تست آنلاین کرونا علائم خود را بررسی کنید و اگر مشکوک بودید میتوانید به صورت فوری با پزشکان عمومی مشاوره
            آنلاین داشته باشید.

        </p>
        <a href="">
            دریافت مشاوره کرونا &nbsp;&nbsp;&nbsp;&gt;
            <!--            دریافت مشاوره کرونا   &gt;-->

        </a>
    </div>
</div>
<div class="download-app">
    <a href="" class="col1">

        <img class="img1" src="https://www.darmankade.com/_nuxt/img/6177b76.png">
        <div class="apps">
            <img src="https://www.darmankade.com/_nuxt/img/0a657d6.png">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAABJCAMAAABWzbUyAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAA2UExURUdwTK+vr7Ozs7Ozs7e3t7Ozs7Ozs7Ozs7Ozs7KysrW1tbOzs7S0tLKysrKysrOzs7S0tLOzsxz1VZQAAAARdFJOUwAQgNAg4ECg8MAwkHBgsFBfVK6zxgAAAYlJREFUGBmdwIeRhDAQBMCRXTngJv9k/3HibBWrxl3R5jRjSAv8lzEgBm4y9CoPAjXhyUIrs1ugVHmB0sLLDKXAS4TOxEuGUuClQKfwYqFU2TloZZ6cgVbmQaDHXVowgKtQDe7xsdkWPXY1i12witbmXO3D45dFEnehFnTmMbML1eOLR+Az9zBYFUl8JR5viuOH2T5q4KfU8GJK1BCDS6OSMzg1qgkOEwc0bHziAIvNTL0UsYnUCwW7TLVUsCvUKzhUqlmcArUCTp5qE04TtRI6Sy1Bl6k1ocvUiugStQw6quFCNYOOahEd1SK6QK2KLlMroBOqFZws1QSnhXoFB089h1OinuAwc4BgN3GEGKw8h7iIleMY8QAaB1UAhoMW/Js5JGAVOcRi4zjCYzNxgODgqOdxiFQTdJlKyaDziToNTxpVMl5kKiSPFybxvglvIm+b8cHyJmfwSXhLKvhGeEMq+E74JNQlAj5axyeu4Jcl8TAv6LwkHqrBb6blxDA3jxdmkhxcbh7P/gDssLlSuHSqjwAAAABJRU5ErkJggg=="
                 style="height:31px;width:27px;padding-right:10px;padding-left:10px">
            <img src="https://www.darmankade.com/_nuxt/img/aa22ae4.png">

        </div>


    </a>


    <div class="col2">
        <h5>
            دانلود اپلیکیشن درمانکده
        </h5>
        <p class="p1">
            با اپلیکیشن درمانکده با پزشکان و روانشناسان آنلاین مشاوره کنید یا برای ویزیت حضوری آنلاین نوبت بگیرید.
        </p>
        <div>
            <p>

            </p>
            <div>
                <p style="font-size: 17px; font-weight: 700; ">
                    برای دریافت لینک دانلود، شماره موبایل خود را وارد کنید.
                </p>
                <div class="send-link">
                    <input maxlength="11"
                           type="text"
                           placeholder="    مانند  ******* 0912  "
                           required="required"
                           id="tel" value=""
                           class="form-control col-6 rounded-10 shadow-sm ml-1 h-100"
                    >

                    <div class="send-link-button">
                        <div class="phone-icon"><!---->
                            <svg xmlns="http://www.w3.org/2000/svg" width="1.3em" height="1.3em" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                 stroke-linejoin="round" class="feather feather-smartphone text-white " e>
                                <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
                                <line x1="12" y1="18" x2="12" y2="18"></line>
                            </svg>
                        </div>
                        <p class="fixed-button">
                            ارسال لینک
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="clearfix">

</div>
<div class="footer">
    <div class="footer-row1">
        <img src="https://www.darmankade.com/_nuxt/img/7bbb5c4.svg">
        <p>
            درمانکده، ارائه دهنده خدمات آنلاین سلامت
            <br/>
            (نوبت گیری اینترنتی، مشاوره آنلاین، آزمایش در محل و ...)
        </p>
    </div>
    <div class="footer-row2">
        <div class="footer-row2-col1">
            <ul>
                <li>
                    <a href="/about/">
                        درباره درمانکده
                    </a>
                </li>
                <li>
                    <a href="/contact/">
                        تماس با ما
                    </a>
                </li>
                <li>
                    <a href="https://www.darmankade.com/blog/">
                        مجله پزشکی
                    </a>
                </li>
            </ul>
        </div>
        <div class="footer-row2-col2">
            <ul class="list-inline list-unstyled text-center d-flex justify-content-between w-50 p-0 m-auto"
                data-v-1c02d2dc>
                <li class="social" data-v-1c02d2dc><a href="https://www.instagram.com/darmankade/" target="_blank"
                                                      data-v-1c02d2dc>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class="text-white p-1 feather feather-instagram" data-v-1c02d2dc>
                        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" data-v-1c02d2dc></rect>
                        <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" data-v-1c02d2dc
                        ></path>
                        <line x1="17.5" y1="6.5" x2="17.5" y2="6.5" data-v-1c02d2dc></line>
                    </svg>
                </a></li>
                <li class="social" data-v-1c02d2dc><a href="https://twitter.com/darmankade" target="_blank"
                                                      style="padding-left: 10rem; padding-right: 10rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class="text-white p-1 feather feather-twitter" data-v-1c02d2dc>
                        <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"
                              data-v-1c02d2dc></path>
                    </svg>
                </a>
                    <div class="verticalLine" data-v-1c02d2dc></div>
                </li>
                <li><a href="https://www.linkedin.com/company/darmankade.ir/"
                       target="_blank">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class="text-white p-1 feather feather-linkedin" data-v-1c02d2dc>
                        <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"
                              data-v-1c02d2dc></path>
                        <rect x="2" y="9" width="4" height="12" data-v-1c02d2dc></rect>
                        <circle cx="4" cy="4" r="2" data-v-1c02d2dc></circle>
                    </svg>
                </a></li>
            </ul>
        </div>
        <div class="footer-row2-col3">
            <ul>
                <li><a href="/faq/">
                    سوالات متداول
                </a></li>
                <li><a href="/terms/">
                    قوانین و مقررات
                </a></li>
                <li><a href="/report/">
                    شکایت
                </a></li>
            </ul>
        </div>
    </div>
    <div class="footer-row3">
        <p>
            با ثبت‌نام در خبرنامه درمانکده، اولین نفری باشید که از جدیدترین خبرها، جشنواره‌ها و تخفیف های ویژه ما مطلع
            می‌شوید
        </p>
    </div>


    <div class="footer-row4">

        <div class="">
            <input type="text"
                   placeholder="  نام  "
                   name="FirstName"
                   value=""
                   class="form-control"
            >
            <input type="text" placeholder="  نام خانوادگی  " name="LastName" value=""
            ></div>
        <input type="text" name="Email" placeholder="  ایمیل  " value="" style="width: 70%;">

        <div class="orange-button">
            <svg xmlns="http://www.w3.org/2000/svg" width="1.3em" height="1.3em" viewBox="0 0 24 24"
                 fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                 stroke-linejoin="round"
                 style="color: white; display: inline-block; position:absolute; right:7px;top:25%">
                <line x1="19" y1="12" x2="5" y2="12"></line>
                <polyline points="12 19 5 12 12 5"></polyline>
            </svg>
            <div class="arrow-icon"><!---->

            </div>
            <p>
                عضو می شوم
            </p>

        </div>
    </div>
    <div class="footer-row5">
        <img alt="logo-samandehi"
             onclick="window.open('https://logo.samandehi.ir/Verify.aspx?id=1020917&p=rfthobpduiwkobpdpfvlrfthjyoe', 'Popup', 'toolbar=no, scrollbars=no, location=no, statusbar=no, menubar=no, resizable=0')"
             src="img/samandehi.png"
             style="cursor:pointer; margin-left: 1rem">
        <a target="_blank"
           href="https://trustseal.enamad.ir/?id=107984&Code=TIxyyDUwLE22aX96fu2X"
           data-v-1c02d2dc><img
                src="img/enamad.png" alt="enamad"
                style="cursor:pointer; margin-right: 1rem;"></a>

    </div>

</div>
<!--        white line at the end-->
<div class=" bg-white" data-v-1c02d2dc>
    <div><span class="col-6 text-slate text-12">تمامی حقوق این سایت برای درمانکده محفوظ است</span>
        <span style="float: left"> طراحی شده با
            <svg style="color: #fb815e; fill: #fb815e"
                 xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none"
                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                 class="svg-fill-red feather feather-heart" data-v-1c02d2dc>
                <path
                        d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"
                        data-v-1c02d2dc>

                </path>
            </svg>
            توسط تیم درمانکده
        </span>
    </div>
</div>
</body>

</html>