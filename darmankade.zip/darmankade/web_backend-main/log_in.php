<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>log_in</title>
</head>
<body>
    
    <form action="log_in.php" method="POST">
    <?php include('errors.php'); ?>
        <div>
            <label for="username">username :</label>
            <input type="text" name="username" required>
        </div>
      
        <div>
            <label for="password">password :</label>
            <input type="password" name="password" required>
        </div>
       
        <button type="submit" name="log_in">submit</button>

    </form>
    
</body>
</html>