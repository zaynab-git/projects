<?php 
  session_start(); 

  if (!isset($_SESSION['patient'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: log_in.php');
  }
  if (isset($_GET['log_out'])) {
  	session_destroy();
  	unset($_SESSION['patient']);
  	header("location: log_in.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class="header">
	<h2>Home Page</h2>
</div>
<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
    <?php  if (isset($_SESSION['patient'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['patient']; ?></strong></p>
		<p>you are now loged in</p>
		<p> <a href="change_info.php" style="color: red;">change your information</a> </p>
		<p> <a href="home.php" style="color: red;">home</a> </p>
		
    	<p> <a href="patient.php?log_out='1'" style="color: red;">logout</a> </p>
    <?php endif ?>
</div>
		
</body>
</html>