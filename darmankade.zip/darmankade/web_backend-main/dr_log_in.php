<?php include('dr_server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dr_log_in</title>
</head>
<body>
    
    <form action="dr_log_in.php" method="POST">
    <?php include('errors.php'); ?>
        <div>
            <label for="username">username :</label>
            <input type="text" name="username" required>
        </div>
      
        <div>
            <label for="password">password :</label>
            <input type="password" name="password" required>
        </div>
       
        <button type="submit" name="dr_log_in">submit</button>

    </form>
    
</body>
</html>