<?php
session_start();

// initializing variables
$username = "";
$phone    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'darmankadeh');

// REGISTER USER
if (isset($_POST['sign_up'])) {
  // receive all input values from the form
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $phone = mysqli_real_escape_string($db, $_POST['phone']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($phone)) { array_push($errors, "phone is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or phone
  $user_check_query = "SELECT * FROM patient WHERE username='$username' OR phone='$phone' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['phone'] === $phone) {
      array_push($errors, "phone already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (empty($errors)) {
    $password = $password_1;//encrypt the password before saving in the database
    // $password = $password_1;
  	$query = "INSERT INTO patient (username, password, phone ) 
  			  VALUES('$username', '$password' ,'$phone' )";
  	mysqli_query($db, $query);
  	$_SESSION['patient'] = $username;
    $_SESSION['success'] = "You are now logged in";
    header('location: patient.php');
  }
}

if (isset($_POST['log_in'])) {
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
  
    if (empty($username)) {
        array_push($errors, "Username is required");
    }
    if (empty($password)) {
        array_push($errors, "Password is required");
    }
  
    if (count($errors) == 0) {
        $query = "SELECT * FROM patient WHERE username='$username' LIMIT 1";
        $results = mysqli_query($db, $query);
        $user = mysqli_fetch_assoc($results);
        if ($user['username'] === $username and $user['password'] === $password) {

            $_SESSION['patient'] = $username;
            $_SESSION['success'] = "You are now logged in";
            header('location: patient.php');
        }
        else {
            array_push($errors, "Wrong username/password combination");
        }
    }
  }

   if (isset($_POST['change_patient'])) {
     $username = $_SESSION['patient'];
     $password = mysqli_real_escape_string($db, $_POST['password']);
     $phon = mysqli_real_escape_string($db, $_POST['phon']);
    
    
     if (!empty($password)) {$query = "UPDATE patient
      set password = '$password' 
      WHERE username = '$username'";
      mysqli_query($db, $query);}
      if (!empty($phon)) {$query = "UPDATE patient
        set phone = '$phone' 
        WHERE username = '$username'";
        mysqli_query($db, $query);}
        $_SESSION['success'] = "Your information changed successfuly!";
        header('location: patient.php');
        
     }
  
  
  ?>