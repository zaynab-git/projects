<?php include('dr_server.php');

if (!isset($_SESSION['dr'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: dr_log_in.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dr_change_info</title>

    <script>
        function show_info(d){
        fetch('https://intense-ravine-40625.herokuapp.com/doctors/4')
   .then(response => response.json())
   .then(data => {
            var info = document.getElementById('info');
            info.innerHTML = 'username: '+ d['username'] + ' phone: ' + d['phone'] + ' password: ' + d['password']
            + ' number :' + d['number'] + ' address :' + d['address'] + ' experience years :' + d['experience_years'] ; 
            if (d['online_pay'] == 1){info.innerHTML += ' online pay: دارد';}
            else {info.innerHTML += ' online pay: ندارد';}
            if (d['spec'] == '1'){info.innerHTML += ' specialities : مغز'; }
            if (d['spec'] == '2'){info.innerHTML += ' specialities : رادیولوژی'; }
            if (d['spec'] == '3'){info.innerHTML += ' specialities : قلب'; }
            info.innerHTML += ' active days of week ';
            if (d['1'] == 1){info.innerHTML += ' شنبه ';}
            if (d['2'] == 1){info.innerHTML += ' یک شنبه ';}
            if (d['3'] == 1){info.innerHTML += ' دو شنبه ';}
            if (d['4'] == 1){info.innerHTML += ' سه شنبه ';}
            if (d['5'] == 1){info.innerHTML += ' چهار شنبه ';}
            if (d['6'] == 1){info.innerHTML += ' پنج شنبه ';}
            if (d['7'] == 1){info.innerHTML += ' جمعه ';}
        });
        }
    </script>

</head>


<?php

$db = mysqli_connect('localhost', 'root', '', 'darmankadeh');

    $username = $_SESSION['dr'];
    
    $query = "SELECT * FROM doctor WHERE username='$username' LIMIT 1";
        $results = mysqli_query($db, $query);
        $user = mysqli_fetch_assoc($results);
    
    

    $arr = array("username"=>$user['username'],"phone"=>$user['phone'],"password"=>$user['password'],"number"=>$user['number'],
    "spec"=>$user['spec'],"address"=>$user['address'],"online_pay"=>$user['online_pay'],"experience_years"=>$user['experience_years'],
    "1"=>$user['week_days_1'],"2"=>$user['week_days_2'],"3"=>$user['week_days_3'],"4"=>$user['week_days_4'],"5"=>$user['week_days_5'],"6"=>$user['week_days_6'],"7"=>$user['week_days_7']);
    
    
    $j = json_encode($arr);
    // echo $j['name'];
 echo "<script> show_info($j); </script>"; 


?>



<body>

<p id="info">
    </p>
    
    <form action="dr_change_info.php" method="POST">
    <?php include('errors.php'); ?>
        <div>
            <label for="password">password :</label>
            <input type="text" name="password">
        </div>
    <div>
            <label for="phone">phone :</label>
            <input type="phone" name="phone">
        </div>
        <div>
            <label for="name">name :</label>
            <input type="text" name="name" >
        </div>

        <div>
            <label for="number">number :</label>
            <input type="text" name="number" >
        </div>

        <div>
            <label for="experience_years">experience_years :</label>
            <input type="number" name="experience_years" >
        </div>

        <div>
            <label for="address">address :</label>
            <input type="text" name="address" >
        </div>

        <fieldset>
    <legend> :تخصص را انتخاب کنید </legend>
    <div>
    <label for="contactChoice1">قلب</label>
      <input type="radio"
       name="spec" value="1">
      
       <label for="contactChoice2">مغز</label>
      <input type="radio" 
       name="spec" value="2">
      
       <label for="contactChoice3">رادیولوژی</label>
      <input type="radio" 
       name="spec" value="3">
      
    </div>
        </fieldset>
    <fieldset>
    <legend> :نوع ویزیت را انتخاب کنید </legend>
    <div>
        <label for="online_pay">ندارد</label>
      <input type="radio" 
       name="online_pay" value="y">
      
       <label for="online_pay">دارد</label>
      <input type="radio" 
       name="online_pay" value="n">
      
    </div>
    </fieldset>

    <fieldset>
    <legend> :روز های فعال در هفته را انتخاب کن </legend>
    <div>
      <input type="checkbox" 
       name="days[]" value="0" checked>
      <label for="contactChoice1">شنبه</label>

      <input type="checkbox" 
       name="days[]" value="1" checked>
      <label for="contactChoice1"> یک شنبه</label>

      <input type="checkbox" 
       name="days[]" value="2" checked>
      <label for="contactChoice1">دو شنبه</label>

      <input type="checkbox" 
       name="days[]" value="3" checked>
      <label for="contactChoice1">سه شنبه</label>

      <input type="checkbox" 
       name="days[]" value="4" checked>
      <label for="contactChoice1">چهار شنبه</label>

      <input type="checkbox" 
       name="days[]" value="5" checked>
      <label for="contactChoice1">پنج شنبه</label>

      <input type="checkbox" 
       name="days[]" value="6" checked>
      <label for="contactChoice1">جمعه</label>
    </div>
    </fieldset>

       
    <button type="submit" name="dr_change">submit</button>
    </form>
    
    
    
</body>
</html>