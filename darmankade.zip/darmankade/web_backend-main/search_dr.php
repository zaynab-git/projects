<?php
session_start();
// initializing variables
$username = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'darmankadeh');

if (isset($_POST['search_dr'])) {
    $search =  $_POST['search'];
    
   
    if (! empty($search)) {
        $query = "CALL search_doctor('$search')";
        $results = mysqli_query($db, $query);
        $drs = mysqli_fetch_all($results);
        
         if(count($drs) == 1){
            $dr_user = $drs[0][0];
              header('location: dr_info.php?dr='.$dr_user);
          }
          else{
              header('location: DRs_list.php?dr='.$search);
          }
    }
}

?>