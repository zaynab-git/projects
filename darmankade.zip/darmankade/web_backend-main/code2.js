// export function fill_drInf(id){
//     window.open("doctor_Inf");
//     console.log(id);
// }
const api_url =
    "https://intense-ravine-40625.herokuapp.com/doctors/"+window.name;
var inf = "matab";
var data;
console.log(window.name);
console.log(api_url);

async function getapi(url) {

    // Storing response
    const response = await fetch(url);

    // Storing data in form of JSON
    data = await response.json();
    console.log(data);
    if (response) {
        hideloader();
    }
    show(data);
}
function getSign(i){
    var r
    if (data.week_days[i]==true) {
        r = `
    <svg data-v-543f99ea="" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
         fill="none" color="green" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
         className="text-dark-mint feather feather-check">
        <polyline data-v-543f99ea="" points="20 6 9 17 4 12"></polyline>
    </svg>
    `
    }
    else {
        r=`
        <svg data-v-543f99ea="" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"
             fill="none" color="red" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
             className="text-primary feather feather-x">
            <line data-v-543f99ea="" x1="18" y1="6" x2="6" y2="18"></line>
            <line data-v-543f99ea="" x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
        `
    }
    return r;
}
getapi(api_url);

function hideloader() {
    // document.getElementById('drsList').style.display = 'none';
    document.getElementsByClassName('active')[0].innerHTML = null;
    document.getElementsByClassName('active_1')[0].innerHTML = null;
    document.getElementsByClassName('sticky-top-img')[0].src = null;
}
function show(data) {
    let tab = ``;
    console.log(data.name);
    document.getElementsByClassName("active")[0].innerHTML = " "+data.name;
    document.getElementsByClassName("active_1")[0].innerHTML = data.spec;
    document.getElementsByClassName("sticky-top-img")[0].src = data.avatar;
    document.getElementsByClassName("blueBoxName")[0].innerHTML = data.name;
    document.getElementsByClassName("blueBoxSpec")[0].innerHTML = data.spec;
    document.getElementsByClassName("blueBoxNumber")[0].innerHTML =" شماره نظام پزشکی: " + data.number;
    document.getElementsByClassName("experience_years")[0].innerHTML = "تجربه" + "</br>" + data.experience_years + " سال " ;
    document.getElementsByClassName("first_empty_date")[0].innerHTML =  "اولین نوبت آزاد" +"</br>" + data.first_empty_date;
    var online = "ندارد"
    if(data.online_pay===true){
        online= "دارد";
    }
    var cont;
    document.getElementsByClassName("online_pay")[0].innerHTML = "پرداخت آنلاین" + "</br>" +online;
    document.getElementsByClassName("howManyComments")[0].innerHTML = " از "+ data.comments + " نظر ";
    document.getElementsByClassName("commenter")[0].innerHTML = data.commenter;
    document.getElementsByClassName("s_comment")[0].innerHTML = data.comment_text;
    document.getElementsByClassName("rate")[0].innerHTML = data.rate;


    if (inf=="matab"){
        document.getElementsByClassName("matab-inf")[0].style.color = "blue";
        document.getElementsByClassName("matab-inf")[0].style.backgroundColor = "white";
        document.getElementsByClassName("days-inf")[0].style.color = "black";
        document.getElementsByClassName("days-inf")[0].style.backgroundColor= "#d2d3d5";


        cont =

                              `<div class="map" style="display:inline-block; float: right;     width: 44%">
                                  <img src="https://www.darmankade.com/Content/UploadFiles/LocationMedicalCenters/205image.png"
                                    style="vertical-align: middle;
                                    border-style: none;
                                    width: 100%;
                                    margin: 15px;
                                    float: right;">

                              </div>
                              <div class="address" style="    display: inline-block;
                                    float: right;

                                    margin-top: 50px;
                                    width: 50%;
                                    text-align: right;
                                    margin-right: 26px;">
                                  <div class="matab-1">
                                  `+
                                     data.address;
                                    +`
                                  </div>
                                  <div class="telephone">`+
                                      data.phone +`
                                  </div>
                              </div> ` ;

        document.getElementsByClassName("inf-container")[0].innerHTML = cont;

    }
    else{
        document.getElementsByClassName("days-inf")[0].style.color = "blue";
        document.getElementsByClassName("days-inf")[0].style.backgroundColor = "white";
        document.getElementsByClassName("matab-inf")[0].style.color = "black";
        document.getElementsByClassName("matab-inf")[0].style.backgroundColor= "#d2d3d5";
        cont = `
            <div>
                `+data.address+`
            </div>
            <div style="margin-top:1.5rem; margin-right: 3rem">
                 <ul style=" list-style-type: none;
                    margin: 0;
                    padding: 0;
                    overflow: hidden;">
                    <li class="day-inf">
                        <div >
                            شنبه
                            </br>
                            `+
                            getSign(0)
                             +
                            
                       `</div>
                    </li>
                    <li class="day-inf">
                        <div>
                            یکشنبه
                            </br>
                             `+
                            getSign(1)
                             +`
                            
                        </div>
                    </li><li class="day-inf">
                        <div>
                            دوشنبه
                            </br>
                            `+
                                 getSign(2)
                             +`
                            
                           
                        </div>
                    </li><li class="day-inf">
                        <div>
                            سه شنبه
                            </br>
                             `+
                                 getSign(3)
                             +`
                            
                        </div>
                    </li>
                    <li class="day-inf" >
                        <div>
                            چهارشنبه
                            </br>
                             `+
                                 getSign(4)
                             +`
                            
                        </div>
                    </li>
                    <li class="day-inf">
                        <div>
                            پنج شنبه
                            </br>
                             `+
                                 getSign(5)
                             +`
                            
                        </div>
                    </li>
                    <li class="day-inf">
                        <div>
                            جمعه
                            </br>
                             `+
                                 getSign(6)
                             +`
                            
                        </div>
                    </li>
                  
                
                </ul>
            </div>
        `
        document.getElementsByClassName("inf-container")[0].innerHTML = cont;
        console.log("****"+data.week_days[2]);

    }



}
function changeInf(flag){
    if (flag==1){
        inf = "matab";
    }
    else {
        inf = "days";
    }
    show(data);
}
