<?php include('dr_server.php') 
?>

<!doctype html>
<html dir="rtl" lang="fa">

<head>
    <title>dr_info</title>
    <meta data-n-head="ssr" charset="utf-8">
    <meta data-n-head="ssr" name="viewport" content="width=device-width, initial-scale=1">
    <meta data-n-head="ssr" data-hid="title" name="title" content="درمانکده - مشاوره آنلاین و ویزیت حضوری - آزمایش در محل">
    <link rel="stylesheet" href="style0.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
    <script>
    function displayInfo(jsn){
        
        fetch('https://intense-ravine-40625.herokuapp.com/doctors/4')
   .then(response => response.json())
   .then(data => {
       data = jsn;
        // console.log(jsn['name']);
        var name = document.getElementsByClassName('name');
        name[0].innerHTML = data['name'];
        name[1].innerHTML = data['name'];
            

            var spec = document.getElementsByClassName('spec');
            spec[0].innerHTML = data['spec'];
            spec[1].innerHTML = data['spec'];

            if (data['1'] == 0){document.getElementsByClassName('day')[0].setAttribute('src','img/cross.png');}
            if (data['2'] == 0){document.getElementsByClassName('day')[1].setAttribute('src','img/cross.png');}
            if (data['3'] == 0){document.getElementsByClassName('day')[2].setAttribute('src','img/cross.png');}
            if (data['4'] == 0){document.getElementsByClassName('day')[3].setAttribute('src','img/cross.png');}
            if (data['5'] == 0){document.getElementsByClassName('day')[4].setAttribute('src','img/cross.png');}
            if (data['6'] == 0){document.getElementsByClassName('day')[5].setAttribute('src','img/cross.png');}
            if (data['7'] == 0){document.getElementsByClassName('day')[6].setAttribute('src','img/cross.png');}
        
        

         if (data['online_pay'] == 1){
             document.getElementsByClassName('online_pay')[0].innerHTML = 'دارد';
         }
         else{
             document.getElementsByClassName('online_pay')[0].innerHTML = 'ندارد';
         }
         document.getElementsByClassName('rate')[0].innerHTML = data['rate'];
         document.getElementsByClassName('address')[0].innerHTML = data['address'];
         document.getElementsByClassName('experience_years')[0].innerHTML = data['experience_years'];
         document.getElementsByClassName('phone')[0].innerHTML = data['phone'];
         document.getElementsByClassName('number')[0].innerHTML = data['number'];
         document.getElementsByClassName('commenter')[0].innerHTML = data['commenter'];
         document.getElementsByClassName('comment_text')[0].innerHTML = data['comment_text'];
         document.getElementsByClassName('comments')[0].innerHTML = data['comments'];
    });

    document.getElementsByClassName('week_bdy')[0].style.display = 'none';
  
}

// نمایش بخش آدرس و شماره تلفن
function show_map(){
    document.getElementsByClassName('week_bdy')[0].style.display = 'none';
    document.getElementsByClassName('map_bdy')[0].style.display = 'block';
}

// نمایش بخش روز های هفته
function show_week(){
    document.getElementsByClassName('week_bdy')[0].style.display = 'block';
    document.getElementsByClassName('map_bdy')[0].style.display = 'none';
}

</script>

</head>

<?php 

$db = mysqli_connect('localhost', 'root', '', 'darmankadeh');

if (isset($_GET['dr'])) {
    $username = $_GET['dr'];
    
    $query = "SELECT * FROM doctor WHERE username='$username' LIMIT 1";
        $results = mysqli_query($db, $query);
        $user = mysqli_fetch_assoc($results);


        $query = "SELECT count(time) FROM comments WHERE doctor_username='$username'";
        $results = mysqli_query($db, $query);
        $count = mysqli_fetch_assoc($results);
    
    
        $query = "SELECT * FROM comments WHERE doctor_username='$username' ORDER BY time DESC lIMIT 1";
        $results = mysqli_query($db, $query);
        $com = mysqli_fetch_assoc($results);

        $query = "SELECT count(rate) FROM rates WHERE doctor_username='$username'";
        $results = mysqli_query($db, $query);
        $rate_count = mysqli_fetch_assoc($results);

        $query = "SELECT sum(rate) FROM rates WHERE doctor_username='$username'";
        $results = mysqli_query($db, $query);
        $sum_count = mysqli_fetch_assoc($results);


        $rate = intval($sum_count) / intval($rate_count);



    $arr = array("name"=>$user['name'],"number"=>$user['number'],"experience_years"=>$user['experience_years'],
                    "rate"=>$rate,"commenter"=>$com['patient_username'],"comments"=>$count['count(time)'],"comment_text"=>$com['comment'],"address"=>$user['address'],"phone"=>$user['phone'],
                "online_pay"=>$user['online_pay'], "1"=>$user['week_days_1'],"2"=>$user['week_days_2'],"3"=>$user['week_days_3'],"4"=>$user['week_days_4'],"5"=>$user['week_days_5'],"6"=>$user['week_days_6'],"7"=>$user['week_days_7']);
                if ($user['spec']=="2"){$arr["spec"] = "روماتولوژی";}
        if ($user['spec']=="3"){$arr["spec"] = "قلب";}
        if ($user['spec']=="1"){$arr["spec"] = "مغز";}
    $j = json_encode($arr);
    // echo $j['name'];
 echo "<script> displayInfo($j); </script>"; 
}



if (isset($_GET['comment'])){
    if (!isset($_SESSION['patient'])) {
      $_SESSION['msg'] = "You must log in first";
      header('location: log_in.php');
    }
    else{
         if (!isset($_GET['dr'])){
             header('location: '.$_SERVER['HTTP_REFERER'].'&comment='.$_GET['comment']);
         }
         else{
            
                $username = $_SESSION['patient'];
                $comment = $_GET['comment'];
                $dr = $_GET['dr'];
                $query = "CALL comment('$dr','$username','$comment')";
                $results = mysqli_query($db, $query);
             
            
         }
      
      
    }
  }


if (isset($_GET['rate'])){
    if (!isset($_SESSION['patient'])) {
      $_SESSION['msg'] = "You must log in first";
      header('location: log_in.php');
    }
    else{
         if (!isset($_GET['dr'])){
             header('location: '.$_SERVER['HTTP_REFERER'].'&rate='.$_GET['rate']);
         }
         else{
            $username = $_SESSION['patient'];
            $rate = $_GET['rate'];
            $dr = $_GET['dr'];
            $query = "CALL rate('$dr','$username','$rate')";
            $results = mysqli_query($db, $query);
         }
      
      
    }
  }



?>
<body >

    <!-- توضیحات مربوط به هدر و فوتر در فایل مربوط به لست پزشکان وجود دارد -->
    <header class="navbar navbar-expand-lg navbar-light bg-white" style="font-size: 13px; font-weight: 400; padding: 1rem 10rem; top: 0px; color: #3B4157;">
        
        <a class="navbar-brand" href="#">
            <img src="https://www.darmankade.com/_nuxt/img/cd3eac7.svg" alt="درمانکده">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

    <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="#">
                <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:0;">
                        <line x1="21" y1="10" x2="3" y2="10">
                        </line>
                        <line x1="21" y1="6" x2="3" y2="6">
                        </line>
                        <line x1="21" y1="14" x2="3" y2="14"></line>
                        <line x1="21" y1="18" x2="3" y2="18"></line>
                    </svg>
                    لیست تخصص ها
              </a>
              <div class="drop-down dropdown-menu-right"  style="background-color: white; border-radius: 5px;">
                <div style="width: 100%; text-align: right; display: flex;flex-direction: row; align-items: stretch;">
                    <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/c825bc8.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        گوارش، کبد و آندوسکوپی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMi4yNSIgaGVpZ2h0PSIyOC42ODUiIHZpZXdCb3g9IjAgMCAzMi4yNSAyOC42ODUiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDY4Ljc1IC0xOTUpIj48cmVjdCB3aWR0aD0iMjciIGhlaWdodD0iMjciIHJ4PSIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDc0IDE5NSkiIGZpbGw9IiNmZWUyYmEiLz48cGF0aCBkPSJNMzgwLjA2LDI0MS4yODF2Ljg3NGEyMi4xMDUsMjIuMTA1LDAsMCwxLTIuMDIxLDkuMiwzLjU5MiwzLjU5MiwwLDAsMS0zLjI1MiwyLjA4MSwzLjU1MiwzLjU1MiwwLDAsMS0yLjUzMi0xLjA0OUwzNjkuMiwyNDkuMzNhNS4xODgsNS4xODgsMCwwLDAtNy4zMzgsMGwtMy4wNTYsMy4wNTVhMy41NTYsMy41NTYsMCwwLDEtMi41MzIsMS4wNDksMy41OTIsMy41OTIsMCwwLDEtMy4yNTItMi4wODEsMjIuMTA2LDIyLjEwNiwwLDAsMS0yLjAyMS05LjJ2LS44NzNhMjIuMSwyMi4xLDAsMCwxLDIuMDIxLTkuMiwzLjU4MSwzLjU4MSwwLDAsMSw1Ljc4NC0xLjAzMmwzLjA1NiwzLjA1NmE1LjE5MSw1LjE5MSwwLDAsMCw3LjMzOCwwbDMuMDU2LTMuMDU2YTMuNTgsMy41OCwwLDAsMSw1Ljc4MywxLjAzMkEyMi4wOSwyMi4wOSwwLDAsMSwzODAuMDYsMjQxLjI4MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcxOC41IC0zMC41KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMTc4MGRmIiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS13aWR0aD0iMS41Ii8+PC9nPjwvc3ZnPg==" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        غدد و متابولیسم
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/09709b8.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        گوش ،حلق و بینی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/42073bf.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        مغز و اعصاب
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/0fa4e19.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        خون و آنکولوژی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/4b862e5.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        زنان و زایمان
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                    </div>
                    <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/d25b940.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                       پوست و مو
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/33fe84f.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        روماتولوژی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/4e329ca.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        جراحی مغز و اصاب
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/6deb567.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                        روانپزشکی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                        <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                            <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                <img src="https://www.darmankade.com/_nuxt/img/bbb08de.svg" >
                                <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                    <span>
                                       اورتوپدی
                                    </span>
                                </div>
                            </div> <!---->
                        </a>
                
                        <button style="margin-bottom: 1rem; margin-right: 1rem;">
                            مشاهده همه
                            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                <polyline points="15 18 9 12 15 6"    >
                                </polyline>
                            </svg>
                        </button>
                    </div>
                    <img src="https://www.darmankade.com/_nuxt/img/8d6a3eb.png" alt="از بهترین پزشکان تهران آنلاین نوبت بگیرید!" style="width: 35%; height: auto; flex-grow: 1;">
                </div>
            </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-0 dr-menu__icon feather feather-wifi">
                        <path d="M5 12.55a11 11 0 0 1 14.08 0">
                        </path>
                        <path d="M1.42 9a16 16 0 0 1 21.16 0">
                        </path>
                        <path d="M8.53 16.11a6 6 0 0 1 6.95 0">
                        </path>
                        <line x1="12" y1="20" x2="12" y2="20"></line>
                    </svg>
                    لیست مشاوره آنلاین
                </a>
                <div class=" dropdown-menu-right drop-down">
                    <div style="width: 100%; background-color: white; margin: auto; text-align: right;border-radius: 15px; display: flex;flex-direction: row; align-items: stretch;">
                        <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/bbb0bf5.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                           روانشناس
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/4b862e5.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            زنان و زایمان
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMi4yNSIgaGVpZ2h0PSIyOC42ODUiIHZpZXdCb3g9IjAgMCAzMi4yNSAyOC42ODUiPjxnIHRyYW5zZm9ybT0idHJhbnNsYXRlKC0xMDY4Ljc1IC0xOTUpIj48cmVjdCB3aWR0aD0iMjciIGhlaWdodD0iMjciIHJ4PSIyIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgxMDc0IDE5NSkiIGZpbGw9IiNmZWUyYmEiLz48cGF0aCBkPSJNMzgwLjA2LDI0MS4yODF2Ljg3NGEyMi4xMDUsMjIuMTA1LDAsMCwxLTIuMDIxLDkuMiwzLjU5MiwzLjU5MiwwLDAsMS0zLjI1MiwyLjA4MSwzLjU1MiwzLjU1MiwwLDAsMS0yLjUzMi0xLjA0OUwzNjkuMiwyNDkuMzNhNS4xODgsNS4xODgsMCwwLDAtNy4zMzgsMGwtMy4wNTYsMy4wNTVhMy41NTYsMy41NTYsMCwwLDEtMi41MzIsMS4wNDksMy41OTIsMy41OTIsMCwwLDEtMy4yNTItMi4wODEsMjIuMTA2LDIyLjEwNiwwLDAsMS0yLjAyMS05LjJ2LS44NzNhMjIuMSwyMi4xLDAsMCwxLDIuMDIxLTkuMiwzLjU4MSwzLjU4MSwwLDAsMSw1Ljc4NC0xLjAzMmwzLjA1NiwzLjA1NmE1LjE5MSw1LjE5MSwwLDAsMCw3LjMzOCwwbDMuMDU2LTMuMDU2YTMuNTgsMy41OCwwLDAsMSw1Ljc4MywxLjAzMkEyMi4wOSwyMi4wOSwwLDAsMSwzODAuMDYsMjQxLjI4MVoiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDcxOC41IC0zMC41KSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMTc4MGRmIiBzdHJva2UtbWl0ZXJsaW1pdD0iMTAiIHN0cm9rZS13aWR0aD0iMS41Ii8+PC9nPjwvc3ZnPg==" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            غدد و متابولیسم
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/6ebe09c.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            کودکان
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/614597c.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            گوارش، کبد و آندوسکوپی
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <button style="margin-bottom: 1rem; margin-right: 1rem;" >
                                مشاوره آنلاین فوری
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                    <polyline points="15 18 9 12 15 6"    >
                                    </polyline>
                                </svg>
                            </button>
                        </div>
                        <div style="display: flex;flex-direction: column; align-items: stretch; flex-grow: 1;">
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/6deb567.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            روانپزشک
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/3a03010.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                           بیماری های عفونی و تبدار
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/d25b940.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            پوست و مو
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/f03344c.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            کلیه و مجاری ادراری
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            <a href="#" class="text-decoration-none" style=" flex-grow: 1; ">
                                <div style="display: flex;flex-direction: row; align-self: center; padding: 1rem;">
                                    <img src="https://www.darmankade.com/_nuxt/img/09709b8.svg" >
                                    <div style="font-size: 13px; padding-top: 0.7rem; padding-right: 0.2rem;">
                                        <span>
                                            گوش، حلق و بینی
                                        </span>
                                    </div>
                                </div> <!---->
                            </a>
                            
                            <button style="margin-bottom: 1rem; margin-right: 1rem;" >
                                مشاهده همه
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-left"    >
                                    <polyline points="15 18 9 12 15 6"    >
                                    </polyline>
                                </svg>
                            </button>
                        </div>
                        <img src="https://www.darmankade.com/_nuxt/img/1d6b04b.png" alt="از بهترین پزشکان تهران آنلاین نوبت بگیرید!" style="width: 35%; height: auto; flex-grow: 1;">
                    </div>
                </div>
                
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dr-menu__icon feather feather-book"    >
                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"    >
                        </path>
                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"    >
                        </path>
                    </svg>
                    <span class="text-14"  >
                        مجله پزشکی 
                   </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dr-menu__icon feather feather-user-plus"  >
                        <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"  ></path>
                        <circle cx="8.5" cy="7" r="4"  ></circle>
                        <line x1="20" y1="8" x2="20" y2="14"  ></line>
                        <line x1="23" y1="11" x2="17" y2="11"  ></line>
                    </svg> 
                    <span class="text-14"  >
                     عضویت پزشکان 
                    </span>
                </a>
            </li>
            <li class="nav-item" style="padding-left: 12rem;">
                <a class="nav-link" href="#">
                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="dr-menu__icon feather feather-box"    >
                        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"    ></path>
                        <polyline points="3.27 6.96 12 12.01 20.73 6.96"    ></polyline>
                        <line x1="12" y1="22.08" x2="12" y2="12"    ></line>
                    </svg>
                    <span class="text-14"  >
                        کرونا سازمانی 
                    </span> 
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link enter enter border-0 text-16 ml-2 bg-transparent bg-white"  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"    >
                        <circle cx="11" cy="11" r="8"    ></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"    ></line>
                    </svg>
                </a>
            </li>
            <li class="nav-item">    
                <div style=" border-radius: 5px; text-align: center; padding: 0rem 0.3rem; background-color: #EDEDED;">
                        <a href="login.html" class="nav-link enter">
                        ورود
                        <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"  ></path>
                            <polyline points="10 17 15 12 10 7"  ></polyline>
                            <line x1="15" y1="12" x2="3" y2="12"  ></line>
                        </svg>
                    </a> 
                </div>   
            </li>
        </ul>
    </div>
</header>

<section style="width: 80%; margin: auto; font-size: 14px; ">
    <nav aria-label="breadcrumb ">
        <ol class="breadcrumb arr-right bg-light">
            <li class="breadcrumb-item"><a class="text-decoration-none bread" href="#" > درمانکده </a></li>
            <li class = 'spec' class="breadcrumb-item"><a class="text-decoration-none bread" href="#" > متخصص مغز و اعصاب (نورولوژی) </a></li>
            <li class = 'name' class="breadcrumb-item active" aria-current="page"> آقای دکتر مهران جلالی </li>
        </ol>
    </nav>
</section>




<section style="width: 80%; margin: auto;">
    <div   data-v-0db0856a><!----> 
        <div class="w-100 pt-md-2"  >
            <div class="pb-md-5 container"    ><!----> 
                <div class="row"    >
                    <div class="pr-md-0 px-0 pl-md-4 col-md-4 col-12"    >
                        <div class="sticky-top" style="background-color: #1780DF; border-radius: 0.5rem; height: 25rem;">
                                <!--  -->
                                <div style="display: flex; flex-direction: row;">
                                    <a style="margin-top: 1rem;margin-right: 1rem;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="hover-p text-white  feather feather-share-2" data-v-58d4bfc9 data-v-58d4bfc9>
                                            <circle cx="18" cy="5" r="3" data-v-58d4bfc9 data-v-58d4bfc9></circle>
                                            <circle cx="6" cy="12" r="3" data-v-58d4bfc9 data-v-58d4bfc9></circle>
                                            <circle cx="18" cy="19" r="3" data-v-58d4bfc9 data-v-58d4bfc9></circle>
                                            <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" data-v-58d4bfc9 data-v-58d4bfc9></line>
                                            <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" data-v-58d4bfc9 data-v-58d4bfc9></line>
                                        </svg>
                                    </a> 
                                    
                                    <img style="width: 7rem; margin-right: 5rem; margin-top: 2rem;" src="https://www.darmankade.com/UploadFiles/Doctor/131899428573066339دکتر-مهران-جلالی.jpg" alt="نوبت دهی دکتر مهران جلالی متخصص مغز و اعصاب(نورولوژی)" class="rounded-circle avatar"  >
                                    
                                   <a style="margin-right: 5rem; margin-top: 1rem;" >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="bookmark__heart--hover feather feather-heart text-white" data-v-390d7861 data-v-390d7861>
                                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" data-v-390d7861 data-v-390d7861></path>
                                    </svg>
                                   </a>
                                </div>
                               
                            <div style="text-align: center; font-weight: bolder; color: white;">
                                <p class="mt-3 name" style="font-size: large;"  >مهران جلالی</p>
                                <p class="mt-3" style="font-size: smaller;"  >
                                    <a href="#" class="text-white text-decoration-none spec"  >
                                       متخصص مغز و اعصاب(نورولوژی)
                                   </a>
                               </p> 
                               <p class="mt-3" style="font-size: smaller;" > <span class = "number" >28863</span> شماره نظام پزشکی :</p>
                            </div>
                            <div style="font-size: smaller; text-align: center; border-radius: 0.5rem; background-color: white;margin: 1rem; display: flex; flex-direction: row;"  > 
                                <div class="col p-2 row"  >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="m-1 w-100 feather feather-book"    >
                                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"    ></path>
                                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"    ></path>
                                    </svg> 
                                    <p style="margin-right: 2.5rem;" > تجربه <br><span class="experience_years">27</span>  سال </p>
                                    
                                </div> 
                                <div class="col p-2 row"  >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="m-1 w-100 feather feather-clock"    >
                                        <circle cx="12" cy="12" r="10"    ></circle>
                                        <polyline points="12 6 12 12 16 14"    ></polyline>
                                    </svg> 
                                    <p style="margin-right: 1.5rem;" > اولین نوبت آزاد <br><span class="first_empty_date">31 فروردین  </span></p>
                                </div> 
                                <div class="col p-2 row"  >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="m-1 w-100 feather feather-credit-card"    >
                                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"    ></rect>
                                        <line x1="1" y1="10" x2="23" y2="10"    ></line>
                                    </svg> 
                                    <p style="margin-right: 1.5rem;" > پرداخت آنلاین <br><span class="online_pay">دارد</span></p>
                                </div>
                            </div> 
                            </div>
                        </div> 
                        <div class=" col-md-8"    ><!----> 
                            <div class="card" style="border-radius: 0.5rem;"><!----><!---->
                                <div class="card-header row" style="background-color: rgba(0,0,0,0);">
                                    <button type="button" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle w-30 text-white font-weight-bold btn-primary rounded-5 mr-2"  >
                                        انتخاب مطب
                                        </button> 
                                        <div aria-labelledby="navbarDropdown" class="dropdown-menu text-right rounded-10"  >
                                            <a class="dropdown-item "  >چهارراه پونک، خیابان میرزابابایی، روبروی درب پارکینگ شهروند، ساختمان پزشکان پونک، طبقه 4</a>
                                        </div>
                                </div>
                                <div class="round_bdy">
                                    <ul>
                                        <i class="fa fa-chevron-circle-right" aria-hidden="true"></i>
                                        <li class="li_frst_chld">
                                            <h6>دوشنبه</h6>
                                            <span>1</span>
                                            <p>دی</p>
                                        </li>
                                        <li>
                                            <h6>یکشنبه</h6>
                                            <span>2</span>
                                            <p>دی</p>
                                        </li>
                                        <li class="li_thrd_chld">
                                            <h6>شنبه</h6>
                                            <span>3</span>
                                            <p>دی</p>
                                        </li>
                                        <li>
                                            <h6>جمعه</h6>
                                            <span>4</span>
                                            <p>دی</p>
                                        </li>
                                        <li>
                                            <h6>پنجشنبه</h6>
                                            <span>5</span>
                                            <p>دی</p>
                                        </li>
                                        <li>
                                            <h6>چهارشنبه</h6>
                                            <span>6</span>
                                            <p>دی</p>
                                        </li>
                                        <i class="fa fa-chevron-circle-left" aria-hidden="true"></i>
                                    </ul>
                                </div>
                                <div class="card-body">
                                    <div style="text-align: right; border-style: solid; border-width: thin; border-color: lightgray;" >
                                          <div style="display: flex; flex-direction: row; margin-left: 20rem;">
                                            <svg style="margin: 1rem;"  xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"    >
                                                <circle cx="12" cy="12" r="10"    ></circle>
                                                <polyline points="12 6 12 12 16 14"    ></polyline>
                                            </svg> 
                                            <p style="width: 100%; margin-top: 1rem;">ساعت های نوبت شنبه 6دی</p>
                                          </div>
                                        
                                          <div style="display: flex; flex-direction: row; margin: 1rem 1rem;">
                                               <button class="btn btn-secondary px-3 py-2 font-weight-bold" style="color: white;">
                                                     17:30
                                               </button>
                                               <button class="btn btn-secondary px-3 py-2 mr-3 font-weight-bold" style="color: white;">
                                                     19:00
                                                </button>
                                          </div>
                                    </div>
                                </div>
                                
                                
                               
                            </div>

                            <div class="top_cmnt">
                                <div class="grant_bx">
                                    <h4 class="rate">4.5</h4>
                                    <ul>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                        <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    </ul>
                                    <p>از <span class="comments">35</span> نظر </p>
                                </div>
                                <div class="cmnt_side">
                                    <span class="commenter">
                                          نظر حدیقه:</span>
                                    <p class="comment_text">با توجه به معاینه هایی که انجام دادن و داروهایی که دادن تا به الان که راضی ام و باید ازمایشاتم و ببرم بازهم براشون تا ادامه روند درمان و پیگیری کنیم . </p>
                                </div>
                            </div>

                            <div class="adres_map">
                                <div class="map_header">
                                    <button onclick="show_map()" class="actv"><i class="fa fa-map-o" aria-hidden="true"></i>  اطلاعات مطب</button>
                                    <button onclick="show_week()" class="non_actv">
                                          روزهای حضور</button>
                                </div>
                                <div class="map_bdy">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-5 col-lg-6">
                                                <div class="map_img">
                                                    <img src="https://www.darmankade.com/Content/UploadFiles/LocationMedicalCenters/134image.png" alt="map">
                                                </div>
                                            </div>
                                            <div class="col-xl-7 col-lg-6">
                                                <div class="adrs_bx">
                                                    <h6>آدرس مطب 1 :</h6>
                                                    <p class="address">خیابان پاسداران، ابتدای بوستان نهم، ساختمان مهر، پلاک 133، طبقه 1، واحد3 </p>
                                                    <span>تلفن گویا : <a href="#" class="phone" >02162743344</a></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="week_bdy" style="display: none;">
                                    <div class="container">
                                        <div class="round_bdy">
                                            <ul>
                                                
                                                <li >
                                                    <h6>شنبه</h6>
                                                    <img class="day" src="img/check.png" alt="#" style="width: 2rem;">
                                                    
                                                </li>
                                                <li class="li_thrd_chld">
                                                    <h6>یکشنبه</h6>
                                                    <img class="day" src="img/check.png" alt="#" style="width: 2rem;">
                                                   
                                                </li>
                                                <li >
                                                    <h6>دو شنبه</h6>
                                                    <img class="day" src="img/check.png" alt="#" style="width: 2rem;">
                                                    
                                                </li >
                                                <li class="li_thrd_chld">
                                                    <h6> سه شنبه</h6>
                                                    <img class="day" src="img/check.png" alt="#" style="width: 2rem;">
                                                    
                                                </li>
                                                <li >
                                                    <h6>چهارشنبه</h6>
                                                    <img class="day" src="img/check.png" alt="#" style="width: 2rem;">
                                                    
                                                </li>
                                                <li class="li_thrd_chld">
                                                    <h6>پنجشنبه</h6>
                                                    <img class="day" src="img/check.png" alt="#" style="width: 2rem;">
                                                    
                                                </li>
                                                <li >
                                                    <h6>جمعه</h6>
                                                    <img class="day" src="img/check.png" alt="#" style="width: 2rem;">
                                                    
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>


<div>
<form action="dr_info.php" method="GET">

        <div>
            <label for="comment">comment :</label>
            <input type="text" name="comment" required>
        </div>
       
        <button type="submit" name="dr_info">submit</button>

    </form>
</div>

<form action="dr_info.php" method="GET">

        <div>
            <label for="rate">rate :</label>
            <input type="number" name="rate" max='5' min='0' required>
        </div>
       
        <button type="submit" name="rate_">submit</button>

    </form>
</div>


                   
<div class=" border p-0" style="border-radius: 0.5rem; margin-top: 1rem;"  >
    <div class="border-bottom rounded-top-10 d-flex justify-content-between pt-2 pr-4" style="background-color: #EDEDED;">
        <div class="row align-self-center">
            <svg  xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate feather feather-message-square">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
            </svg> 
            <div class="pr-3" style="text-align: right;">
               <h6>
                نظرات کاربران (تعداد کل نظرات :<span class="comments">52</span>)
               </h>
               <p style="font-size: 12px; padding-top: 1rem;">
                در این قسمت شما می توانید تجربه مراجعه کاربران دیگر به مطب آقای دکتر مهران جلالی را بخوانید.
               </p>
            </div>
        </div> 
        </div> 
        <div class="w-100 p-3 bg-white" style="border-radius: 0.5rem;"  >
            <div  >
                <div class="row text-right justify-content-between">
                    <div class="col-md-5 col-12 mr-3">
                        <h5 class="text-slate font-weight-bold text-14">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star">
                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                            </svg> امتیاز به پزشک
                        </h5> 
                        <div class="row mb-2"    >
                            <span  >5 ستاره </span> 
                            <div class="m-auto col"    >
                                <div class="mt-1 progress"  >
                                    <div role="progressbar" aria-valuemin="0" aria-valuemax="52" aria-valuenow="43" class="progress-bar" style="width:82.6923076923077%;">
                                    </div>
                                </div>
                            </div> 
                            <span  >43</span>
                        </div> 
                        <div class="row mb-2"    >
                            <span  >4 ستاره </span> 
                            <div class="m-auto col"    >
                                <div class="mt-1 progress"  >
                                    <div role="progressbar" aria-valuemin="0" aria-valuemax="52" aria-valuenow="6" class="progress-bar" style="width:11.538461538461538%;">
                                    </div>
                                </div>
                            </div> 
                            <span  >6</span>
                        </div> 
                        <div class="row mb-2"    >
                            <span  >3 ستاره </span> 
                            <div class="m-auto col"    >
                                <div class="mt-1 progress"  >
                                    <div role="progressbar" aria-valuemin="0" aria-valuemax="52" aria-valuenow="2" class="progress-bar" style="width:3.8461538461538463%;">
                                    </div>
                                </div>
                            </div> 
                            <span  >2</span>
                        </div> 
                        <div class="row mb-2"    >
                            <span  >2 ستاره </span>
                             <div class="m-auto col"    >
                                 <div class="mt-1 progress"  >
                                     <div role="progressbar" aria-valuemin="0" aria-valuemax="52" aria-valuenow="0" class="progress-bar" style="width:0%;">
                                    </div>
                                </div>
                            </div> 
                            <span  >0</span>
                        </div> 
                        <div class="row mb-2"    >
                            <span  >1 ستاره </span> 
                            <div class="m-auto col"    >
                                <div class="mt-1 progress"  >
                                    <div role="progressbar" aria-valuemin="0" aria-valuemax="52" aria-valuenow="1" class="progress-bar" style="width:1.9230769230769231%;">
                                    </div>
                                </div>
                            </div> 
                            <span  >1</span>
                        </div>
                    </div>
                    
                        <div style="display: flex; flex-direction: row; margin-left: 5rem; ">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"    >
                                <circle cx="12" cy="12" r="10"    ></circle>
                                <polyline points="12 6 12 12 16 14"    ></polyline>
                            </svg> 
                            <p style="width: 100%; padding-right: 0.5rem; font-size: small; font-weight: bolder;"> میانگین زمان انتظار برای <br>45 دقیقه</p>
                        </div>
                    
                </div> 
                <div style="font-size: small; border-radius: 0.5rem;" class=" row bg-white border py-2 my-3 mx-2">
                    <div class="row px-2 px-md-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate feather feather-align-right">
                            <line x1="21" y1="10" x2="7" y2="10"></line>
                            <line x1="21" y1="6" x2="3" y2="6"></line>
                            <line x1="21" y1="14" x2="3" y2="14"></line>
                            <line x1="21" y1="18" x2="7" y2="18"></line>
                        </svg> 
                        <span class="text-slate text-14 font-weight-bold mr-3">مرتب سازی براساس :</span>
                    </div> 
                    <span class="mx-md-3 px-2 text-steel cursor-pointer text-14 p-1 ">
                    جدیدترین
                </span>
                <span class="mx-md-3 px-2 text-steel cursor-pointer text-14 p-1 ">
                    بیشترین امتیاز
                </span>
                <span class="mx-md-3 px-2 text-steel cursor-pointer text-14 p-1 btn btn-primary">
                    مفید ترین نظرات
                </span>
            </div> 
            <div class="d-block m-md-0 mb-4">
                <div class="w-100 p-0">
                    <div style="border-radius: 0.5rem;" class=" border p-0 mb-3 text-right">
                        <div class="border-bottom rounded-top-10 d-flex justify-content-between p-2" style="background-color: #EDEDED;">
                            <div class="row align-self-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate feather feather-user mr-3">
                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="12" cy="7" r="4"></circle>
                                </svg> 
                                <div class="pr-3">
                                    <p style="font-size: 12px;" class="mb-0 w-100 d-block  text-steel mt-1">
                                        نظر سمانه در تاریخ 09 آذر 1399
                                    </p> <!---->
                                </div>
                            </div> 
                            <div style="color: #4DCC6B;" class="d-flex flex-column align-self-center text-dark-mint" data-v-f144f462>
                                <svg  xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="cursor-pointer ml-2 feather feather-thumbs-up " data-v-f144f462 data-v-f144f462>
                                    <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" data-v-f144f462 data-v-f144f462></path>
                                </svg> 
                                <span class="text-center w-auto text-dark-mint text-12" data-v-f144f462>0</span>
                            </div>
                        </div> 
                        <div class="bg-white pb-1 pt-2 row rounded-bottom-10">
                            <div class="text-14 py-1 col-md-5 col-12">
                                <div class="w-100 pb-1 d-flex h-auto text-slate text-14">
                                    <span class="text-slate font-weight-bold w-50"> علت مراجعه </span> 
                                    <span class="w-50 pr-1">سردرد</span>
                                </div> 
                                <div class="w-100 d-flex h-auto pb-1 text-slate text-14">
                                    <span class="w-50 text-slate font-weight-bold">امتیاز به پزشک</span> 
                                    <div class="w-50">
                                        <div style="color: #1780DF;">
                                            
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="py-1 col-md-7 col-12 border-right-dash">
                                <p style="font-size: 15px;" class="text-slate line-height-30 p-2">
                                     از طریق یکی از دوستان با آقای دکتر آشنا شدم و به ایشون مراجعه کردم خیلی برای بیمار وقت میذارن و به بهترین نحو جواب سوالات بیمار رامیدن،فعلا نوار مغز گرفتن سی تی اسکن هم باید انجام بدم و برای دکتر ببرم اون موقع میتونم درباره تشخیص و درمان آقای دکتر نظر بدم، 
                                 </p>
                            </div>
                        </div>
                    </div>
                    <div style="border-radius: 0.5rem;" class=" border p-0 mb-3 text-right">
                        <div class="border-bottom rounded-top-10 d-flex justify-content-between p-2" style="background-color: #EDEDED;">
                            <div class="row align-self-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate feather feather-user mr-3">
                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="12" cy="7" r="4"></circle>
                                </svg> 
                                <div class="pr-3">
                                    <p style="font-size: 12px;" class="mb-0 w-100 d-block  text-steel mt-1">
                                        نظر سمانه در تاریخ 09 آذر 1399
                                    </p> <!---->
                                </div>
                            </div> 
                            <div style="color: #4DCC6B;" class="d-flex flex-column align-self-center text-dark-mint" data-v-f144f462>
                                <svg  xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="cursor-pointer ml-2 feather feather-thumbs-up " data-v-f144f462 data-v-f144f462>
                                    <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" data-v-f144f462 data-v-f144f462></path>
                                </svg> 
                                <span class="text-center w-auto text-dark-mint text-12" data-v-f144f462>0</span>
                            </div>
                        </div> 
                        <div class="bg-white pb-1 pt-2 row rounded-bottom-10">
                            <div class="text-14 py-1 col-md-5 col-12">
                                <div class="w-100 pb-1 d-flex h-auto text-slate text-14">
                                    <span class="text-slate font-weight-bold w-50"> علت مراجعه </span> 
                                    <span class="w-50 pr-1">سردرد</span>
                                </div> 
                                <div class="w-100 d-flex h-auto pb-1 text-slate text-14">
                                    <span class="w-50 text-slate font-weight-bold">امتیاز به پزشک</span> 
                                    <div class="w-50">
                                        <div style="color: #1780DF;">
                                            
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="py-1 col-md-7 col-12 border-right-dash">
                                <p style="font-size: 15px;" class="text-slate line-height-30 p-2">
                                     از طریق یکی از دوستان با آقای دکتر آشنا شدم و به ایشون مراجعه کردم خیلی برای بیمار وقت میذارن و به بهترین نحو جواب سوالات بیمار رامیدن،فعلا نوار مغز گرفتن سی تی اسکن هم باید انجام بدم و برای دکتر ببرم اون موقع میتونم درباره تشخیص و درمان آقای دکتر نظر بدم، 
                                 </p>
                            </div>
                        </div>
                    </div>
                    <div style="border-radius: 0.5rem;" class=" border p-0 mb-3 text-right">
                        <div class="border-bottom rounded-top-10 d-flex justify-content-between p-2" style="background-color: #EDEDED;">
                            <div class="row align-self-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate feather feather-user mr-3">
                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="12" cy="7" r="4"></circle>
                                </svg> 
                                <div class="pr-3">
                                    <p style="font-size: 12px;" class="mb-0 w-100 d-block  text-steel mt-1">
                                        نظر سمانه در تاریخ 09 آذر 1399
                                    </p> <!---->
                                </div>
                            </div> 
                            <div style="color: #4DCC6B;" class="d-flex flex-column align-self-center text-dark-mint" data-v-f144f462>
                                <svg  xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="cursor-pointer ml-2 feather feather-thumbs-up " data-v-f144f462 data-v-f144f462>
                                    <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" data-v-f144f462 data-v-f144f462></path>
                                </svg> 
                                <span class="text-center w-auto text-dark-mint text-12" data-v-f144f462>0</span>
                            </div>
                        </div> 
                        <div class="bg-white pb-1 pt-2 row rounded-bottom-10">
                            <div class="text-14 py-1 col-md-5 col-12">
                                <div class="w-100 pb-1 d-flex h-auto text-slate text-14">
                                    <span class="text-slate font-weight-bold w-50"> علت مراجعه </span> 
                                    <span class="w-50 pr-1">سردرد</span>
                                </div> 
                                <div class="w-100 d-flex h-auto pb-1 text-slate text-14">
                                    <span class="w-50 text-slate font-weight-bold">امتیاز به پزشک</span> 
                                    <div class="w-50">
                                        <div style="color: #1780DF;">
                                            
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="py-1 col-md-7 col-12 border-right-dash">
                                <p style="font-size: 15px;" class="text-slate line-height-30 p-2">
                                     از طریق یکی از دوستان با آقای دکتر آشنا شدم و به ایشون مراجعه کردم خیلی برای بیمار وقت میذارن و به بهترین نحو جواب سوالات بیمار رامیدن،فعلا نوار مغز گرفتن سی تی اسکن هم باید انجام بدم و برای دکتر ببرم اون موقع میتونم درباره تشخیص و درمان آقای دکتر نظر بدم، 
                                 </p>
                            </div>
                        </div>
                    </div>
                    <div style="border-radius: 0.5rem;" class=" border p-0 mb-3 text-right">
                        <div class="border-bottom rounded-top-10 d-flex justify-content-between p-2" style="background-color: #EDEDED;">
                            <div class="row align-self-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate feather feather-user mr-3">
                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="12" cy="7" r="4"></circle>
                                </svg> 
                                <div class="pr-3">
                                    <p style="font-size: 12px;" class="mb-0 w-100 d-block  text-steel mt-1">
                                        نظر سمانه در تاریخ 09 آذر 1399
                                    </p> <!---->
                                </div>
                            </div> 
                            <div style="color: #4DCC6B;" class="d-flex flex-column align-self-center text-dark-mint" data-v-f144f462>
                                <svg  xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="cursor-pointer ml-2 feather feather-thumbs-up " data-v-f144f462 data-v-f144f462>
                                    <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" data-v-f144f462 data-v-f144f462></path>
                                </svg> 
                                <span class="text-center w-auto text-dark-mint text-12" data-v-f144f462>0</span>
                            </div>
                        </div> 
                        <div class="bg-white pb-1 pt-2 row rounded-bottom-10">
                            <div class="text-14 py-1 col-md-5 col-12">
                                <div class="w-100 pb-1 d-flex h-auto text-slate text-14">
                                    <span class="text-slate font-weight-bold w-50"> علت مراجعه </span> 
                                    <span class="w-50 pr-1">سردرد</span>
                                </div> 
                                <div class="w-100 d-flex h-auto pb-1 text-slate text-14">
                                    <span class="w-50 text-slate font-weight-bold">امتیاز به پزشک</span> 
                                    <div class="w-50">
                                        <div style="color: #1780DF;">
                                            
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="py-1 col-md-7 col-12 border-right-dash">
                                <p style="font-size: 15px;" class="text-slate line-height-30 p-2">
                                     از طریق یکی از دوستان با آقای دکتر آشنا شدم و به ایشون مراجعه کردم خیلی برای بیمار وقت میذارن و به بهترین نحو جواب سوالات بیمار رامیدن،فعلا نوار مغز گرفتن سی تی اسکن هم باید انجام بدم و برای دکتر ببرم اون موقع میتونم درباره تشخیص و درمان آقای دکتر نظر بدم، 
                                 </p>
                            </div>
                        </div>
                    </div>
                    <div style="border-radius: 0.5rem;" class=" border p-0 mb-3 text-right">
                        <div class="border-bottom rounded-top-10 d-flex justify-content-between p-2" style="background-color: #EDEDED;">
                            <div class="row align-self-center">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-slate feather feather-user mr-3">
                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="12" cy="7" r="4"></circle>
                                </svg> 
                                <div class="pr-3">
                                    <p style="font-size: 12px;" class="mb-0 w-100 d-block  text-steel mt-1">
                                        نظر سمانه در تاریخ 09 آذر 1399
                                    </p> <!---->
                                </div>
                            </div> 
                            <div style="color: #4DCC6B;" class="d-flex flex-column align-self-center text-dark-mint" data-v-f144f462>
                                <svg  xmlns="http://www.w3.org/2000/svg" width="1.5em" height="1.5em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="cursor-pointer ml-2 feather feather-thumbs-up " data-v-f144f462 data-v-f144f462>
                                    <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" data-v-f144f462 data-v-f144f462></path>
                                </svg> 
                                <span class="text-center w-auto text-dark-mint text-12" data-v-f144f462>0</span>
                            </div>
                        </div> 
                        <div class="bg-white pb-1 pt-2 row rounded-bottom-10">
                            <div class="text-14 py-1 col-md-5 col-12">
                                <div class="w-100 pb-1 d-flex h-auto text-slate text-14">
                                    <span class="text-slate font-weight-bold w-50"> علت مراجعه </span> 
                                    <span class="w-50 pr-1">سردرد</span>
                                </div> 
                                <div class="w-100 d-flex h-auto pb-1 text-slate text-14">
                                    <span class="w-50 text-slate font-weight-bold">امتیاز به پزشک</span> 
                                    <div class="w-50">
                                        <div style="color: #1780DF;">
                                            
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="star-rating feather feather-star" data-v-41e50536>
                                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" data-v-41e50536></polygon>
                                            </svg>
                                            
                                        </div>
                                    </div>
                                </div>
                            </div> 
                            <div class="py-1 col-md-7 col-12 border-right-dash">
                                <p style="font-size: 15px;" class="text-slate line-height-30 p-2">
                                     از طریق یکی از دوستان با آقای دکتر آشنا شدم و به ایشون مراجعه کردم خیلی برای بیمار وقت میذارن و به بهترین نحو جواب سوالات بیمار رامیدن،فعلا نوار مغز گرفتن سی تی اسکن هم باید انجام بدم و برای دکتر ببرم اون موقع میتونم درباره تشخیص و درمان آقای دکتر نظر بدم، 
                                 </p>
                            </div>
                        </div>
                    </div>
                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>
        </div>
    </div>
            
</section>

<section>
</div>
<div class="services" style="  margin-right: 0!important;
margin-left: 0!important;
background-size: cover;
height: 45rem;
text-align: center;
margin-top: 50px;
margin-bottom: 5rem">
    <div class=row1>
        <p>
            نگران کرونا نباشید
        </p>
    </div>
    <div style="color: white;
    display: inline-block;
    width: 27%;
      
    padding: 2rem;
    margin-right: 13rem">
        <img src="https://www.darmankade.com/_nuxt/img/994ebdc.png">
        <h4>تست PCR و آنتی بادی در محل</h4>
        <p>اگر در شهرهای تهران، مشهد، اصفهان، کرج، شیراز و اهواز هستید، می‌توانید بدون مراجعه به آزمایشگاه و در محل
            مدنظر خود آزمایش کرونا بدهید.</p>
        <a href="">
           
            درخواست آزمایش ;
        </a>
    </div>
    <div style=" color: white;
    display: inline-block;
    width: 27%;
  
    padding: 2rem;
    margin-left: 13rem">
        <img style="width: 100%;" src="https://www.darmankade.com/_nuxt/img/4126cda.png">
        <h4>
            مشاوره آنلاین فوری
        </h4>
        <p>
            با تست آنلاین کرونا علائم خود را بررسی کنید و اگر مشکوک بودید میتوانید به صورت فوری با پزشکان عمومی مشاوره
            آنلاین داشته باشید.

        </p>
        <a href="">
            دریافت مشاوره کرونا ;
                   

        </a>
    </div>
</div>
<div >
    <a href="" class="col1">

        <img class="img1" src="https://www.darmankade.com/_nuxt/img/6177b76.png">
        <div class="apps">
            <img src="https://www.darmankade.com/_nuxt/img/0a657d6.png">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAABJCAMAAABWzbUyAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAA2UExURUdwTK+vr7Ozs7Ozs7e3t7Ozs7Ozs7Ozs7Ozs7KysrW1tbOzs7S0tLKysrKysrOzs7S0tLOzsxz1VZQAAAARdFJOUwAQgNAg4ECg8MAwkHBgsFBfVK6zxgAAAYlJREFUGBmdwIeRhDAQBMCRXTngJv9k/3HibBWrxl3R5jRjSAv8lzEgBm4y9CoPAjXhyUIrs1ugVHmB0sLLDKXAS4TOxEuGUuClQKfwYqFU2TloZZ6cgVbmQaDHXVowgKtQDe7xsdkWPXY1i12witbmXO3D45dFEnehFnTmMbML1eOLR+Az9zBYFUl8JR5viuOH2T5q4KfU8GJK1BCDS6OSMzg1qgkOEwc0bHziAIvNTL0UsYnUCwW7TLVUsCvUKzhUqlmcArUCTp5qE04TtRI6Sy1Bl6k1ocvUiugStQw6quFCNYOOahEd1SK6QK2KLlMroBOqFZws1QSnhXoFB089h1OinuAwc4BgN3GEGKw8h7iIleMY8QAaB1UAhoMW/Js5JGAVOcRi4zjCYzNxgODgqOdxiFQTdJlKyaDziToNTxpVMl5kKiSPFybxvglvIm+b8cHyJmfwSXhLKvhGeEMq+E74JNQlAj5axyeu4Jcl8TAv6LwkHqrBb6blxDA3jxdmkhxcbh7P/gDssLlSuHSqjwAAAABJRU5ErkJggg=="
                 style="height:31px;width:27px;padding-right:10px;padding-left:10px">
            <img src="https://www.darmankade.com/_nuxt/img/aa22ae4.png">

        </div>


    </a>


    <div class="col2">
        <h5>
            دانلود اپلیکیشن درمانکده
        </h5>
        <p class="p1">
            با اپلیکیشن درمانکده با پزشکان و روانشناسان آنلاین مشاوره کنید یا برای ویزیت حضوری آنلاین نوبت بگیرید.
        </p>
        <div>
            <p>

            </p>
            <div>
                <p style="font-size: 17px; font-weight: 700; ">
                    برای دریافت لینک دانلود، شماره موبایل خود را وارد کنید.
                </p>
                <div style="padding: 1rem;">
                    <input maxlength="11"
                           type="text"
                           placeholder="    مانند  ******* 0912  "
                           required="required"
                           id="tel" value=""
                           class="form-control col-6 rounded-10 shadow-sm ml-1 h-100"
                    >

                    <div style=" display: inline-block;">
                        <div class="phone-icon"><!---->
                            <svg xmlns="http://www.w3.org/2000/svg" width="1.3em" height="1.3em" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                 stroke-linejoin="round" class="feather feather-smartphone text-white " e>
                                <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
                                <line x1="12" y1="18" x2="12" y2="18"></line>
                            </svg>
                        </div>
                        <p class="fixed-button">
                            ارسال لینک
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>




<!-- توضیحات مربوط به هدر و فوتر در فایل مربوط به لیست پزشکان موجود است -->
    <footer style="background-color: #1780DF;">
        <div style="width: 80%; padding: 2rem 0; margin: auto;">
            <div class="container"  >
                <div class="row"  >
                    <div class="col-4"  >
                        <a href="#" title="صفحه اصلی" class="w-100" style="margin-left: 12rem;">
                            <img src="https://www.darmankade.com/_nuxt/img/7bbb5c4.svg" alt="درمانکده"  >
                        </a> 
                        <p class="text-justify text-white col-10 px-0 d-block w-100 float-right pt-3 text-14 mb-0 line-height-30" style="line-height: 30px"  >
                             درمانکده، ارائه دهنده خدمات آنلاین سلامت
                            (نوبت گیری اینترنتی، مشاوره آنلاین، آزمایش در محل و ...)
                        </p>
                    </div> 
                    <div class="col-4 align-self-center"  >
                        <div class="row"  >
                            <div class="col-6"  >
                                <ul class="list-unstyled mb-0 pr-0 text-right"  >
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                             سوالات
                                            متداول
                                        </a>
                                    </li> 
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                            قوانین و
                                            مقررات
                                        </a>
                                    </li> 
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                        شکایت
                                        </a>
                                    </li>
                                </ul>
                            </div> 
                            <div class="col-6"  >
                                <ul class="list-unstyled mb-0 pr-0 text-white text-center"  >
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                            درباره درمانکده
                                        </a>
                                    </li> 
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >
                                            تماس با
                                            ما
                                        </a>
                                    </li> 
                                    <li class="border-top text-center hoverSection py-2"  >
                                        <a href="#" class="text-decoration-none text-14"  >مجله پزشکی</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div> 
                    <div class="col-4"  >
                        <div class="row text-center justify-content-center"  >
                            <div class=" bg-white col-4 ml-3" style="border-radius: 2rem;">
                                <img alt="logo-samandehi" src="img/img1.png" class="w-100 h-auto" >
                            </div> 
                            <div class=" bg-white col-4" style="border-radius: 2rem;"e>
                                <a target="_blank" href="https://trustseal.enamad.ir/?id=107984&Code=TIxyyDUwLE22aX96fu2X"  >
                                    <img src="img/img2.png" alt="enamad" class="w-100 h-auto rounded-10" ></a>
                            </div> 
                            <div  >
                                    <ul class="list-inline list-unstyled mt-4 row px-4 mb-0"  >
                                        <li class=" ml-5"  >
                                            <a  href="https://www.instagram.com/darmankade/" target="_blank"  >
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-white px-1 feather feather-instagram"    >
                                                    <rect x="2" y="2" width="20" height="20" rx="5" ry="5"    ></rect>
                                                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"    ></path>
                                                    <line x1="17.5" y1="6.5" x2="17.5" y2="6.5"    ></line>
                                                </svg>
                                            </a>
                                        </li> 
                                        <li class="social"  >
                                            <a href="https://twitter.com/darmankade" target="_blank"  >
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-white px-1 feather feather-twitter"    >
                                                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"    ></path>
                                                </svg>
                                            </a>
                                        </li> 
                                        <li class="social mr-5"  ><a href="https://www.linkedin.com/company/darmankade.ir/" target="_blank"  >
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-white px-1 feather feather-linkedin"    >
                                                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"    ></path>
                                                <rect x="2" y="9" width="4" height="12"    ></rect>
                                                <circle cx="4" cy="4" r="2"    ></circle>
                                            </svg>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
        <div class="container-fluid bg-white"  >
            <div class="container"  >
                <div class="row justify-content-between align-self-center py-2"  >
                    <p class="text-slate text-12 mb-0"  >
                        تمامی حقوق این سایت برای درمانکده محفوظ است
                    </p> 
                    <p class="text-slate text-12 mb-0"  >
                        طراحی شده با 
                        <span  >
                            <svg style="color: red;" xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="svg-fill-red feather feather-heart"    >
                                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"    ></path>
                            </svg> 
                            توسط تیم درمانکده 
                        </span>
                    </p>
                </div>
            </div>
        </div>
    </footer>



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>

</body>
</html>