<?php include('server.php') ;

if (!isset($_SESSION['patient'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: log_in.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>change_info</title>

    <script>
        function show_info(d){
        fetch('https://intense-ravine-40625.herokuapp.com/doctors/4')
   .then(response => response.json())
   .then(data => {
            var info = document.getElementById('info');
            info.innerHTML = 'username: '+ d['username'] + ' phone: ' + d['phone'] + ' password: ' + d['password']; 
        });
        }
    </script>

</head>

<?php

$db = mysqli_connect('localhost', 'root', '', 'darmankadeh');

    $username = $_SESSION['patient'];
    
    $query = "SELECT * FROM patient WHERE username='$username' LIMIT 1";
        $results = mysqli_query($db, $query);
        $user = mysqli_fetch_assoc($results);
    
    

    $arr = array("username"=>$user['username'],"phone"=>$user['phone'],"password"=>$user['password']);
    $j = json_encode($arr);
    // echo $j['name'];
 echo "<script> show_info($j); </script>"; 


?>

<body >
    <p id="info">
    </p>
    <form action="change_info.php" method="POST">
    <?php include('errors.php'); ?>
        <div>
            <label for="password">password :</label>
            <input type="text" name="password">
        </div>

        <div>
            <label for="phone">phone :</label>
            <input type="phone" name="phone">
        </div>
       
        <button type="submit" name="change_patient">submit</button>
    </form>
    
    
</body>
</html>