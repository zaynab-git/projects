<?php
session_start();

// initializing variables
$username = "";
$phone    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'darmankadeh');

// REGISTER USER
if (isset($_POST['dr_sign_up'])) {
  // receive all input values from the form
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $phone = mysqli_real_escape_string($db, $_POST['phone']);
  $name = mysqli_real_escape_string($db, $_POST['name']);
  $number = mysqli_real_escape_string($db, $_POST['number']);
  $experience_years = mysqli_real_escape_string($db, $_POST['experience_years']);
  $address = mysqli_real_escape_string($db, $_POST['address']);
  $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
  $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);
  $spec = mysqli_real_escape_string($db, $_POST['spec']);
  $online_pay = mysqli_real_escape_string($db, $_POST['online_pay']);
  // echo "<script> alert($online_pay); </script>"; 
  $days = array(0=>0,1=>0,2=>0,3=>0,4=>0,5=>0,6=>0);
  for ($x = 0; $x <= 6; $x++){
    if(in_array("$x", $_POST['days'])){
      $days[$x] = 1;
    }
  }
  

  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($phone)) { array_push($errors, "phone is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if (empty($name)) { array_push($errors, "name is required"); }
  if (empty($number)) { array_push($errors, "number is required"); }
  if (empty($address)) { array_push($errors, "address is required"); }
  if (empty($spec)) { array_push($errors, "spec is required"); }
  if (empty($experience_years)) { array_push($errors, "experience_years is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }

  // first check the database to make sure 
  // a user does not already exist with the same username and/or phone
  $user_check_query = "SELECT * FROM doctor WHERE username='$username' OR phone='$phone' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['phone'] === $phone) {
      array_push($errors, "phone already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (empty($errors)) {
    $password = $password_1;//encrypt the password before saving in the database
    // $password = $password_1;
    if($online_pay === "y"){$online_pay = 1;}
    else{$online_pay = 0;}
  	$query = "INSERT INTO doctor (username, password, phone, experience_years, address, name, number, spec, online_pay, week_days_1,
    week_days_2,week_days_3,week_days_4,week_days_5,week_days_6,week_days_7) 
  			  VALUES('$username', '$password' ,'$phone', '$experience_years', '$address', '$name', '$number', '$spec', '$online_pay', 
          '$days[0]','$days[1]','$days[2]','$days[3]','$days[4]','$days[5]','$days[6]')";
  	mysqli_query($db, $query);
  	$_SESSION['dr'] = $username;
    $_SESSION['success'] = "You are now logged in";
    header('location: dr.php');
  }
}

if (isset($_POST['dr_log_in'])) {
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
  
    if (empty($username)) {
        array_push($errors, "Username is required");
    }
    if (empty($password)) {
        array_push($errors, "Password is required");
    }
  
    if (count($errors) == 0) {
        $query = "SELECT * FROM doctor WHERE username='$username' LIMIT 1";
        $results = mysqli_query($db, $query);
        $user = mysqli_fetch_assoc($results);
        if ($user['username'] === $username and $user['password'] === $password) {

            $_SESSION['dr'] = $username;
            $_SESSION['success'] = "You are now logged in";
            header('location: dr.php');
        }
        else {
            array_push($errors, "Wrong username/password combination");
        }
    }
  }

   if (isset($_POST['dr_change'])) {
    $username = $_SESSION['dr'];
    $phone = mysqli_real_escape_string($db, $_POST['phone']);
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $number = mysqli_real_escape_string($db, $_POST['number']);
    $experience_years = mysqli_real_escape_string($db, $_POST['experience_years']);
    $address = mysqli_real_escape_string($db, $_POST['address']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $spec = mysqli_real_escape_string($db, $_POST['spec']);
    $online_pay = $_POST['online_pay'];
    // echo "<script> alert($online_pay); </script>"; 
    $days = array(0=>0,1=>0,2=>0,3=>0,4=>0,5=>0,6=>0);
    for ($x = 0; $x <= 6; $x++){
      if(in_array("$x", $_POST['days'])){
        $days[$x] = 1;
      }
    }
    

    if (!empty($phone)) { $query = "UPDATE doctor set phone = '$phone' WHERE username = '$username'"; mysqli_query($db, $query); }
    if (!empty($password)) { $query = "UPDATE doctor set password = '$password' WHERE username = '$username'"; mysqli_query($db, $query); }
    if (!empty($name)) { $query = "UPDATE doctor set name = '$name' WHERE username = '$username'"; mysqli_query($db, $query); }
    if (!empty($number)) { $query = "UPDATE doctor set number = '$number' WHERE username = '$username'"; mysqli_query($db, $query); }
    if (!empty($address)) { $query = "UPDATE doctor set address = '$address' WHERE username = '$username'"; mysqli_query($db, $query); }
    if (!empty($spec)) { $query = "UPDATE doctor set spec = '$spec' WHERE username = '$username'"; mysqli_query($db, $query); }
    if (!empty($experience_years)) { $query = "UPDATE doctor set experience_years = '$experience_years' WHERE username = '$username'"; mysqli_query($db, $query); }
    if (!empty($online_pay)) { 
      if($online_pay === "y"){$online_pay = 1;}
      else{$online_pay = 0;}
      $query = "UPDATE doctor set online_pay = '$online_pay' WHERE username = '$username'"; mysqli_query($db, $query); 
    }
    if (!empty($_POST['days'])) { $query = "UPDATE doctor set week_days_2 = '$days[1]',
    week_days_1 = '$days[0]', week_days_3 = '$days[2]',week_days_4 = '$days[3]',week_days_5 = '$days[4]',week_days_6 = '$days[5]',week_days_7 = '$days[6]' WHERE username = '$username'"; mysqli_query($db, $query); }

      $_SESSION['success'] = "Your information changed successfuly!";
      header('location: dr.php');
      
   }

   


  ?>