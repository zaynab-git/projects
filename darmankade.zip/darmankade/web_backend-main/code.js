// import { fill_drInf } from './code2.js';
// api url
const api_url =
    "https://intense-ravine-40625.herokuapp.com/doctors";
let sortByUsePercent = false;
// Defining async function
async function getapi(url) {

    // Storing response
    const response = await fetch(url);

    // Storing data in form of JSON
    var data = await response.json();
    console.log(data);
    if (response) {
        hideloader();
    }
    show(data);
}
// Calling that async function

getapi(api_url);

// Function to hide the loader
function hideloader() {
    // document.getElementById('drsList').style.display = 'none';
    document.getElementsByClassName('drsList').innerHTML = null;
}
function paintStar(stars){
    let str;
    str ='';
    if (stars>=1){
        str = str+
            ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
        if(stars>=2){
            str = str+
                ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24"  stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
            if(stars>=3){
                str = str+
                    ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
                if(stars>=4){
                    str = str+
                        ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24"  stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
                    if(stars==5){
                        str = str+
                            ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24"  stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>
                            `
                    }
                    else{
                        str = str+`
                         <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
                    }
                }
                else{
                    str = str+
                        ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
                }
            }
            else{
                str = str+
                    ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
            }
        }
        else{
            str = str+
                ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
        }

    }
    else{
        str = str+
            ` <div data-v-41e50536 data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width=".8em" height=".8em"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"
                                         data-v-41e50536 data-v-50fd7d5a>
                                        <polygon
                                            points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
                                            data-v-41e50536 data-v-50fd7d5a></polygon>
                                    </svg>
                                </div>`
    }
    return str;

}
// Function to define innerHTML for HTML table
function show(data) {
    let tab = ``;
    // console.log(data);
    // var sortedObjs = _.sortBy( data, 'user_percent' );
    // var sortedArray = _.sortBy(data.results, ['user_percent']);
    // console.log(sortedArray);
    // data.sort(function (a, b) {
    //     return a.user_percent.localeCompare(b.user_percent);
    // });
    if(sortByUsePercent===true) {
        data.sort(function (a, b) {
            return b.user_percent - a.user_percent;
        });
    }
    // _.sortBy(data, 'user_percent');
    console.log(data);
    for (let r of data) {
        tab +=
           `<div class=" row border rounded-10 w-100 mb-3 bg-white py-3" style="border-radius: 1rem;">
                <a href="#" onclick="fill_drInf(`+r.id+`)"  class="text-decoration-none row col-11 col-md-7 pl-md-2 px-0" style="color: black;">
                    <div class="px-0 pl-lg-3 col-4" data-v-50fd7d5a>
                        <img style="width: 7rem;"
                             src= `+ r.avatar+`
                             alt= `+r.name+` class="dr-img rounded-circle" data-v-50fd7d5a> <!---->
                    </div>
                    <div class="pr-md-0 pt-2 col-8" data-v-50fd7d5a>
                        <h5 class="text-slate font-weight-bold d-flex text-18" data-v-50fd7d5a>
                            `+r.name+`
                        </h5>
                        <h6 class="text-slate  d-flex text-15" data-v-50fd7d5a>
                              `+r.spec+`
                        </h6> <!---->
                        <div class="my-md-4 mt-2 mb-3 d-flex pr-3" data-v-50fd7d5a>
                            <div class=" row star-rating" style="color: blue;"> 
                            `+paintStar(r.stars)+`

                            </div>
                            <span class="text-10 pt-1 pr-3" data-v-50fd7d5a> ( <span data-v-50fd7d5a>`+r.comments+`</span> نظر ) </span>
                        </div>
                        <p class="text-slate  d-flex text-15 pl-3" data-v-50fd7d5a>
                        `+r.comment_text+`
                        </p>
                    </div>
                </a> <!---->
                <div class="px-0 pr-md-4 col-md-5 col-12" data-v-50fd7d5a data-v-50fd7d5a>
                    <a href="#" data-v-50fd7d5a><!---->
                        <div class="card border-0 rounded-10 p-3 text-14 align-items-start"
                             style="background: #E5F2FE ;">
                            <ul class="list-unstyled pr-0 text-right text-12 mb-0" data-v-50fd7d5a>
                                <li class="py-1 text-steel" data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round"
                                         class="icon-20 feather feather-map-pin" data-v-50fd7d5a>
                                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" data-v-50fd7d5a></path>
                                        <circle cx="12" cy="10" r="3" data-v-50fd7d5a></circle>
                                    </svg>
                                    <span class="location text-steel mr-3" data-v-50fd7d5a>
                                                     `+r.location+`
                                                </span>
                                </li>
                                <li class="py-1 text-steel " data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round"
                                         class="icon-20 feather feather-book" data-v-50fd7d5a>
                                        <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" data-v-50fd7d5a></path>
                                        <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"
                                              data-v-50fd7d5a></path>
                                    </svg>
                                   <span class="text-steel mr-3" data-v-50fd7d5a>  تجربه کاری `+r.experience_years+` سال 
                                   </span>
                                </li>
                                <li class="pt-1 text-steel " data-v-50fd7d5a>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px"
                                         viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                         stroke-linecap="round" stroke-linejoin="round"
                                         class="icon-20 feather feather-thumbs-up" data-v-50fd7d5a>
                                        <path
                                            d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"
                                            data-v-50fd7d5a></path>
                                    </svg>
                                     <span class="text-steel mr-3" data-v-50fd7d5a>  `+r.user_percent+`  درصد رضایت کاربران
                                     </span>
                                </li>
                            </ul>
                        </div>
                        <!---->
                    </a>
                    <div class="col-12 px-0 pt-3 text-center" data-v-50fd7d5a>
                        <div class="d-inline-flex w-100 justify-content-between" style="height:55px;"
                             data-v-50fd7d5a>
                            <div class="h-100 w-80" data-v-50fd7d5a>
                                <div class="btn text-center row align-items-center nobat">
                                    <div data-v-bc20ae4e>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="1.3em" height="1.3em"
                                             viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                             stroke-linecap="round" stroke-linejoin="round"
                                             class="feather feather-arrow-left text-white " data-v-bc20ae4e
                                             >
                                            <line x1="19" y1="12" x2="5" y2="12" data-v-bc20ae4e ></line>
                                            <polyline points="12 19 5 12 12 5" data-v-bc20ae4e
                                                      ></polyline>
                                        </svg>
                                    </div>
                                    <div class="text-white text-center pr-3 mx-auto" data-v-bc20ae4e>
                                        نوبت بگیر !
                                    </div>
                                </div>
                            </div>
                            <span title=""
                                  class="btn bg-light w-20 mr-2 px-2 h-100  d-flex align-items-center justify-content-center"
                                  style="width:16%; color: blue; border-radius: 0.5rem; " data-v-50fd7d5a>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px"
                                                 viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                                 stroke-linecap="round" stroke-linejoin="round"
                                                 class="heart-icon feather feather-heart text-water-blue"
                                                  data-v-50fd7d5a>
                                                <path
                                                    d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"
                                                    data-v-50fd7d5a></path>
                                            </svg>
                                        </span>
                        </div>
                        <p class="text-center font-weight-medium mb-0 pt-2 "
                           style="font-size: smaller; color: #4DCC70;">
                            اولین نوبت خالی
                             `+r.first_empty_date+`
                        </p>
                    </div>
                </div>
            </div>`;




    }
    // console.log(tab)
    document.getElementsByClassName("drsList")[0].innerHTML = tab;


}
function sortMost_satisfaction(){
    document.getElementsByClassName("selected")[0].style.backgroundColor = 'white';
    document.getElementsByClassName("selected")[0].style.color = 'black';
    document.getElementsByClassName("selected")[0].style.borderColor = 'white';
    document.getElementsByClassName("most_satisfaction")[0].style.backgroundColor = '#1780DF ';
    document.getElementsByClassName("most_satisfaction")[0].style.color = 'white';
    sortByUsePercent = true;
    getapi(api_url);
}
function sortSelected(){
    document.getElementsByClassName("most_satisfaction")[0].style.backgroundColor = 'white';
    document.getElementsByClassName("most_satisfaction")[0].style.color = 'black';
    document.getElementsByClassName("most_satisfaction")[0].style.borderColor = 'white';
    document.getElementsByClassName("selected")[0].style.backgroundColor = '#1780DF ';
    document.getElementsByClassName("selected")[0].style.color = 'white';
    sortByUsePercent = false;
    getapi(api_url);



}
function fill_drInf(id){
    window.open("doctor_Inf.html",id);
}
